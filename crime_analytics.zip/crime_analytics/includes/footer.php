<?php
// includes/footer.php
?>
  </main> <!-- /mainContent -->
</div> <!-- /d-flex -->

<footer class="footer py-3 bg-dark text-light mt-4">
  <div class="container text-center small">
    &copy; <?= date('Y') ?> Crime Analytics
  </div>
</footer>

<!-- Bootstrap JS bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- Chart.js (placeholder, we will use later) -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<!-- Custom JS -->
<script>
(function(){
  // Sidebar toggle for small screens
  const sidebar = document.getElementById('sidebar');
  const sidebarToggleBtn = document.getElementById('sidebarToggleBtn');
  sidebarToggleBtn?.addEventListener('click', () => {
    sidebar.classList.toggle('collapsed');
  });

  // Persist sidebar collapsed state across reloads (small)
  const collapsedClass = 'collapsed';
  const storageKey = 'ca_sidebar_collapsed';
  if (localStorage.getItem(storageKey) === '1') sidebar.classList.add(collapsedClass);

  document.getElementById('sidebarToggleBtn')?.addEventListener('click', () => {
    const isCollapsed = sidebar.classList.toggle(collapsedClass);
    localStorage.setItem(storageKey, isCollapsed ? '1' : '0');
  });

  // Dark mode toggle
  const darkToggle = document.getElementById('darkModeToggle');
  const darkIcon = document.getElementById('darkModeIcon');
  const themeKey = 'ca_dark_mode';
  function applyTheme(isDark){
    document.documentElement.setAttribute('data-theme', isDark ? 'dark' : 'light');
    darkIcon.className = isDark ? 'bi bi-sun-fill' : 'bi bi-moon-stars';
    darkToggle.setAttribute('aria-pressed', isDark ? 'true' : 'false');
  }
  // initialize
  const stored = localStorage.getItem(themeKey);
  const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  const isDark = stored ? stored === '1' : prefersDark;
  applyTheme(isDark);

  darkToggle?.addEventListener('click', () => {
    const next = document.documentElement.getAttribute('data-theme') !== 'dark';
    applyTheme(next);
    localStorage.setItem(themeKey, next ? '1' : '0');
  });
})();
</script>

</body>
</html>
