<?php
require_once __DIR__ . '/../config/database.php';

function log_case_event($case_id, $title, $description = '', $event_type = 'Case', $user_id = null) {
    global $pdo;

    $stmt = $pdo->prepare("
        INSERT INTO case_timeline (case_id, title, description, event_type, created_by)
        VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->execute([$case_id, $title, $description, $event_type, $user_id]);
}
