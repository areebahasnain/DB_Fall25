<?php
// includes/header.php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/auth.php'; // auth.php already checks login

// convenience variables
$role = $_SESSION['role'] ?? 'Guest';
$full_name = $_SESSION['full_name'] ?? ($_SESSION['username'] ?? 'User');
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Crime Analytics</title>

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <!-- Custom CSS -->
  <link href="/crime_analytics/assets/css/style.css" rel="stylesheet">
</head>
<body class="app-body">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
  <div class="container-fluid">
    <a class="navbar-brand d-flex align-items-center gap-2" href="/crime_analytics/index.php">
      <i class="bi bi-shield-lock-fill"></i>
      <span>Crime Analytics</span>
    </a>

    <button class="btn btn-outline-light d-lg-none" id="sidebarToggleBtn" aria-label="Toggle sidebar">
      <i class="bi bi-list"></i>
    </button>

    <div class="ms-auto d-flex align-items-center gap-2">
      <!-- Dark mode toggle -->
      <button class="btn btn-sm btn-outline-light" id="darkModeToggle" title="Toggle dark mode" aria-pressed="false">
        <i class="bi bi-moon-stars" id="darkModeIcon"></i>
      </button>

      <!-- Profile dropdown -->
      <div class="dropdown">
        <a class="nav-link dropdown-toggle text-light" href="#" role="button" id="profileMenu" data-bs-toggle="dropdown" aria-expanded="false">
          <i class="bi bi-person-circle"></i> <?= htmlspecialchars($full_name) ?>
        </a>
        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileMenu">
          <li><a class="dropdown-item" href="/crime_analytics/users/profile.php">Profile</a></li>
          <?php if ($role === 'Admin'): ?>
            <li><a class="dropdown-item" href="/crime_analytics/users/list_users.php">Manage Users</a></li>
          <?php endif; ?>
          <li><hr class="dropdown-divider"></li>
          <li><a class="dropdown-item" href="/crime_analytics/logout.php">Logout</a></li>
        </ul>
      </div>
    </div>
  </div>
</nav>

<div class="d-flex">
  <!-- Sidebar -->
  <nav id="sidebar" class="sidebar bg-sidebar">
    <div class="sidebar-inner p-3">
      <div class="sidebar-section mb-3">
        <div class="small text-muted">Role</div>
        <div class="fw-bold"><?= htmlspecialchars($role) ?></div>
      </div>

      <ul class="nav flex-column">
        <li class="nav-item">
          <a class="nav-link" href="/crime_analytics/index.php">
            <i class="bi bi-speedometer2 me-2"></i> Dashboard
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="/crime_analytics/cases/list_cases.php">
            <i class="bi bi-folder2-open me-2"></i> Cases
          </a>
        </li>

        <?php if($role === 'Officer'): ?>
        <li class="nav-item">
          <a class="nav-link" href="/crime_analytics/cases/my_cases.php">
            <i class="bi bi-briefcase me-2"></i> My Cases
          </a>
        </li>
        <?php endif; ?>

        <li class="nav-item">
          <a class="nav-link" href="/crime_analytics/criminals/wanted_list.php">
            <i class="bi bi-exclamation-octagon me-2"></i> Wanted Criminals
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="/crime_analytics/criminals/list_criminals.php">
            <i class="bi bi-people-fill me-2"></i> Criminals
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="/crime_analytics/officers/list_officers.php">
            <i class="bi bi-people me-2"></i> Officers
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="/crime_analytics/departments/list_departments.php">
            <i class="bi bi-building me-2"></i> Departments
          </a>
        </li>

        <?php if($role === 'Admin'): ?>
        <li class="nav-item">
          <a class="nav-link" href="/crime_analytics/users/list_users.php">
            <i class="bi bi-person-gear me-2"></i> Users
          </a>
        </li>
        <?php endif; ?>

        <?php if(in_array($role, ['Admin','Analyst'])): ?>
        <li class="nav-item">
          <a class="nav-link" href="/crime_analytics/reports/analytics.php">
            <i class="bi bi-graph-up me-2"></i> Analytics
          </a>
        </li>
        <?php endif; ?>
      </ul>
    </div>
  </nav>

  <!-- Main content -->
  <main id="mainContent" class="flex-grow-1 p-4">


  <!-- Main content -->
  <main id="mainContent" class="flex-grow-1 p-4">
