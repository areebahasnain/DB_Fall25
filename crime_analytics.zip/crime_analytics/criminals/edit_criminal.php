<?php
require_once "../config/database.php";
require_once "../includes/functions.php";
require_once "../includes/auth.php";

// Admin & Officer can edit
if (!in_array($_SESSION['role'], ['Admin', 'Officer'])) {
    die("Access denied");
}

if (!isset($_GET['id'])) {
    redirect('list_criminals.php');
}

$criminal_id = (int)$_GET['id'];

// Fetch criminal info
$stmt = $pdo->prepare("
    SELECT criminal_id, full_name, dob, gender, cnic, status
    FROM criminals
    WHERE criminal_id = ?
");
$stmt->execute([$criminal_id]);
$criminal = $stmt->fetch();

if (!$criminal) {
    redirect('list_criminals.php');
}

$error = '';
$success = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = sanitize($_POST['full_name']);
    $dob = sanitize($_POST['dob']);
    $gender = sanitize($_POST['gender']);
    $cnic = sanitize($_POST['cnic']);
    $status = sanitize($_POST['status']);

    // Validation
    if ($full_name === '' || $cnic === '') {
        $error = "Full Name and CNIC are required.";
    } else {
        $update_stmt = $pdo->prepare("
            UPDATE criminals
            SET full_name = ?, dob = ?, gender = ?, cnic = ?, status = ?
            WHERE criminal_id = ?
        ");
        $update_stmt->execute([$full_name, $dob ?: null, $gender ?: null, $cnic, $status, $criminal_id]);

        $_SESSION['success'] = "Criminal record updated successfully";
        redirect('list_criminals.php');
    }
}
?>

<?php include "../includes/header.php"; ?>

<div class="container py-4">
    <div class="card shadow p-4">
        <h3>Edit Criminal Record</h3>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>

        <form method="post">
            <div class="mb-3">
                <label class="form-label">Full Name *</label>
                <input type="text" name="full_name" class="form-control"
                       value="<?= htmlspecialchars($criminal['full_name']) ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label">CNIC *</label>
                <input type="text" name="cnic" class="form-control"
                       value="<?= htmlspecialchars($criminal['cnic']) ?>" placeholder="42101-1234567-8" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Date of Birth</label>
                <input type="date" name="dob" class="form-control"
                       value="<?= $criminal['dob'] ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">Gender</label>
                <select name="gender" class="form-select">
                    <option value="">— Select —</option>
                    <option value="Male" <?= $criminal['gender'] === 'Male' ? 'selected' : '' ?>>Male</option>
                    <option value="Female" <?= $criminal['gender'] === 'Female' ? 'selected' : '' ?>>Female</option>
                    <option value="Other" <?= $criminal['gender'] === 'Other' ? 'selected' : '' ?>>Other</option>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Status *</label>
                <select name="status" class="form-select" required>
                    <option value="Wanted" <?= $criminal['status'] === 'Wanted' ? 'selected' : '' ?>>Wanted</option>
                    <option value="Arrested" <?= $criminal['status'] === 'Arrested' ? 'selected' : '' ?>>Arrested</option>
                    <option value="Released" <?= $criminal['status'] === 'Released' ? 'selected' : '' ?>>Released</option>
                </select>
            </div>

            <button type="submit" class="btn btn-primary">Update Record</button>
            <a href="list_criminals.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</div>

<?php include "../includes/footer.php"; ?>
