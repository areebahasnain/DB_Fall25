<?php
require_once "../config/database.php";
require_once "../includes/functions.php";
require_once "../includes/auth.php";

// Only Admin or Officer can add criminals
if (!in_array($_SESSION['role'], ['Admin', 'Officer'])) {
    die("Access denied");
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize inputs
    $full_name = sanitize($_POST['full_name']);
    $dob = $_POST['dob']; // date, no need to sanitize
    $gender = $_POST['gender'];
    $cnic = sanitize($_POST['cnic']);
    $status = $_POST['status'];

    // Validation
    if ($full_name === '' || $status === '' || $cnic === '') {
        $error = "Full Name, CNIC, and Status are required.";
    } else {
        $stmt = $pdo->prepare("
            INSERT INTO criminals (full_name, dob, gender, cnic, status)
            VALUES (?, ?, ?, ?, ?)
        ");
        try {
            $stmt->execute([$full_name, $dob ?: null, $gender ?: null, $cnic, $status]);
            $success = "Criminal added successfully!";
        } catch (PDOException $e) {
            $error = "Error: " . $e->getMessage();
        }
    }
}
?>

<?php include "../includes/header.php"; ?>

<div class="container py-4">
    <div class="card p-4 shadow">
        <h3>Add Criminal</h3>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success"><?= $success ?></div>
        <?php endif; ?>

        <form method="post">
            <div class="mb-3">
                <label class="form-label">Full Name *</label>
                <input type="text" name="full_name" class="form-control" required>
            </div>

            <div class="mb-3">
                <label class="form-label">CNIC *</label>
                <input type="text" name="cnic" class="form-control" placeholder="42101-1234567-8" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Date of Birth</label>
                <input type="date" name="dob" class="form-control">
            </div>

            <div class="mb-3">
                <label class="form-label">Gender</label>
                <select name="gender" class="form-select">
                    <option value="">— Select —</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Status *</label>
                <select name="status" class="form-select" required>
                    <option value="Wanted">Wanted</option>
                    <option value="Arrested">Arrested</option>
                    <option value="Released">Released</option>
                </select>
            </div>

            <button type="submit" class="btn btn-dark">Add Criminal</button>
            <a href="list_criminals.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</div>

<?php include "../includes/footer.php"; ?>
