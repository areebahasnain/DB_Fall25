<?php
require_once "../config/database.php";
require_once "../includes/functions.php";
require_once "../includes/auth.php";

// Only Admin & Officer can view
if (!in_array($_SESSION['role'], ['Admin', 'Officer'])) {
    die("Access denied");
}

// Handle search
$search = trim($_GET['search'] ?? '');
$params = [];
$sql = "SELECT criminal_id, full_name, dob, gender, cnic, status 
        FROM criminals";

if ($search) {
    $sql .= " WHERE full_name LIKE ? OR cnic LIKE ? OR status LIKE ?";
    $params = ["%$search%", "%$search%", "%$search%"];
}

$sql .= " ORDER BY criminal_id ASC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$criminals = $stmt->fetchAll();
?>

<?php include "../includes/header.php"; ?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Criminal Records</h3>
        <a href="add_criminal.php" class="btn btn-dark">Add Criminal</a>
    </div>

    <!-- Search bar -->
    <form method="get" class="mb-3">
        <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Search by Name, CNIC, or Status..." value="<?= htmlspecialchars($search) ?>">
            <button class="btn btn-primary" type="submit">Search</button>
            <?php if ($search): ?>
                <a href="list_criminals.php" class="btn btn-secondary">Clear</a>
            <?php endif; ?>
        </div>
    </form>

    <div class="card shadow p-3">
        <table class="table table-bordered table-hover">
            <thead class="table-dark">
                <tr>
                    <th>#</th>
                    <th>Full Name</th>
                    <th>DOB</th>
                    <th>Gender</th>
                    <th>CNIC</th>
                    <th>Status</th>
                    <th style="width: 150px;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($criminals)): ?>
                    <tr>
                        <td colspan="7" class="text-center">No criminals found.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($criminals as $c): ?>
                        <tr>
                            <td><?= $c['criminal_id'] ?></td>
                            <td><?= htmlspecialchars($c['full_name']) ?></td>
                            <td><?= $c['dob'] ?: '—' ?></td>
                            <td><?= $c['gender'] ?: '—' ?></td>
                            <td><?= htmlspecialchars($c['cnic'] ?: '—') ?></td>
                            <td>
                                <?php if ($c['status'] === 'Wanted'): ?>
                                    <span class="badge bg-danger">Wanted</span>
                                <?php elseif ($c['status'] === 'Arrested'): ?>
                                    <span class="badge bg-success">Arrested</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Released</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="edit_criminal.php?id=<?= $c['criminal_id'] ?>" class="btn btn-sm btn-primary">Edit</a>
                                <a href="delete_criminal.php?id=<?= $c['criminal_id'] ?>" 
                                   class="btn btn-sm btn-danger"
                                   onclick="return confirm('Are you sure you want to delete this record?');">
                                   Delete
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include "../includes/footer.php"; ?>
