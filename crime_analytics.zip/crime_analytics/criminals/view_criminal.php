<?php
require_once "../config/database.php";
require_once "../includes/functions.php";
require_once "../includes/auth.php";

// Admin & Officer can view
if (!in_array($_SESSION['role'], ['Admin', 'Officer'])) {
    die("Access denied");
}

if (!isset($_GET['id'])) {
    redirect("list_criminals.php");
}

$criminal_id = (int)$_GET['id'];

// Fetch criminal
$stmt = $pdo->prepare("
    SELECT criminal_id, full_name, dob, gender, cnic, status, created_at
    FROM criminals
    WHERE criminal_id = ?
");
$stmt->execute([$criminal_id]);
$criminal = $stmt->fetch();

if (!$criminal) {
    redirect("list_criminals.php");
}
?>

<?php include "../includes/header.php"; ?>

<div class="container py-4">
    <div class="card shadow p-4">
        <h3 class="mb-4">Criminal Details</h3>

        <table class="table table-bordered">
            <tr>
                <th>ID</th>
                <td><?= $criminal['criminal_id'] ?></td>
            </tr>
            <tr>
                <th>Full Name</th>
                <td><?= htmlspecialchars($criminal['full_name']) ?></td>
            </tr>
            <tr>
                <th>Date of Birth</th>
                <td><?= $criminal['dob'] ?: '—' ?></td>
            </tr>
            <tr>
                <th>Gender</th>
                <td><?= $criminal['gender'] ?: '—' ?></td>
            </tr>
            <tr>
                <th>CNIC</th>
                <td><?= htmlspecialchars($criminal['cnic'] ?: '—') ?></td>
            </tr>
            <tr>
                <th>Status</th>
                <td><?= htmlspecialchars($criminal['status']) ?></td>
            </tr>
            <tr>
                <th>Created At</th>
                <td><?= $criminal['created_at'] ?></td>
            </tr>
        </table>

        <a href="edit_criminal.php?id=<?= $criminal['criminal_id'] ?>" class="btn btn-primary">Edit</a>
        <a href="list_criminals.php" class="btn btn-secondary">Back</a>
    </div>
</div>

<?php include "../includes/footer.php"; ?>
