<?php
// /cases/add_case.php
require_once "../config/database.php";
require_once "../includes/functions.php";
require_once "../includes/auth.php";

$errors = [];
$title = $description = $location = $case_date = "";
$status = "Open";
$assigned_officer_id = null;
$department_id = null;

// Fetch officers and departments for dropdowns
// Fetch officers with their full names
$officers = $pdo->query("
    SELECT o.officer_id, u.full_name
    FROM officers o
    JOIN users u ON o.user_id = u.user_id
    ORDER BY u.full_name ASC
")->fetchAll(PDO::FETCH_ASSOC);

// Fetch departments
$departments = $pdo->query("
    SELECT department_id, name
    FROM departments
    ORDER BY name ASC
")->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $location = trim($_POST['location'] ?? '');
    $case_date = $_POST['case_date'] ?: null; // empty string becomes null
    $status = $_POST['status'] ?? 'Open';
    $assigned_officer_id = $_POST['assigned_officer_id'] ?: null;
    $department_id = $_POST['department_id'] ?: null;

    if (!$title) {
        $errors[] = "Title is required.";
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare("
            INSERT INTO cases (title, description, location, case_date, status, assigned_officer_id, department_id)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $title,
            $description,
            $location,
            $case_date,
            $status,
            $assigned_officer_id,
            $department_id
        ]);

        $new_case_id = $pdo->lastInsertId();
        
        require_once "../includes/functions_timeline.php";
        log_case_event($new_case_id, "Case created", "Case titled '$title' was created.", 'Case', $_SESSION['user_id']);

        redirect("view_case.php?id=" . $new_case_id);
    }
}

include "../includes/header.php";
?>

<div class="container mt-4">
    <h4>Add New Case</h4>

    <?php if ($errors): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach ($errors as $e): ?>
                    <li><?= htmlspecialchars($e) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST">
        <div class="mb-3">
            <label class="form-label">Title *</label>
            <input type="text" name="title" class="form-control" value="<?= htmlspecialchars($title) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Description</label>
            <textarea name="description" class="form-control"><?= htmlspecialchars($description) ?></textarea>
        </div>

        <div class="mb-3">
            <label class="form-label">Location</label>
            <input type="text" name="location" class="form-control" value="<?= htmlspecialchars($location) ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Case Date</label>
            <input type="date" name="case_date" class="form-control" value="<?= htmlspecialchars($case_date) ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Status</label>
            <select name="status" class="form-select">
                <option value="Open" <?= $status=='Open'?'selected':'' ?>>Open</option>
                <option value="Under Investigation" <?= $status=='Under Investigation'?'selected':'' ?>>Under Investigation</option>
                <option value="Closed" <?= $status=='Closed'?'selected':'' ?>>Closed</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Assigned Officer</label>
            <select name="assigned_officer_id" class="form-select">
                <option value="">— None —</option>
                <?php foreach ($officers as $o): ?>
                    <option value="<?= $o['officer_id'] ?>" <?= $assigned_officer_id == $o['officer_id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($o['full_name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Department</label>
            <select name="department_id" class="form-select">
                <option value="">— None —</option>
                <?php foreach ($departments as $d): ?>
                    <option value="<?= $d['department_id'] ?>" <?= $department_id == $d['department_id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($d['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <button class="btn btn-primary" type="submit">Add Case</button>
        <a href="list_cases.php" class="btn btn-outline-secondary">Back to List</a>
    </form>
</div>

<?php include "../includes/footer.php"; ?>
