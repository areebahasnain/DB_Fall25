<?php

// /cases/view_case.php
require_once "../config/database.php";
require_once "../includes/functions.php";
require_once "../includes/auth.php";

// Validate case ID
if (!isset($_GET['id'])) {
    redirect("list_cases.php");
}

$case_id = (int)$_GET['id'];

// Fetch case with assigned officer + department
$stmt = $pdo->prepare("
    SELECT c.*, 
           o.officer_id, u.full_name AS officer_name,
           d.name AS dept_name
    FROM cases c
    LEFT JOIN officers o ON c.assigned_officer_id = o.officer_id
    LEFT JOIN users u ON o.user_id = u.user_id
    LEFT JOIN departments d ON c.department_id = d.department_id
    WHERE c.case_id = ?
");
$stmt->execute([$case_id]);
$case = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$case) {
    redirect("list_cases.php");
}

// Determine permission
$role = $_SESSION['role'] ?? 'Analyst';
$user_id = $_SESSION['user_id'] ?? null;

$can_edit = false;
if ($role === 'Admin') {
    $can_edit = true;
} elseif ($role === 'Officer') {
    // Officer can edit only their assigned cases
    $stmt2 = $pdo->prepare("SELECT officer_id FROM officers WHERE user_id = ?");
    $stmt2->execute([$user_id]);
    $officer = $stmt2->fetch();
    if ($officer && $officer['officer_id'] == $case['assigned_officer_id']) {
        $can_edit = true;
    }
}

// validate tab
$allowed_tabs = ['overview','victims','suspects','evidence','documents','timeline','arrests','trials'];
$tab = $_GET['tab'] ?? 'overview';
$tab = in_array($tab, $allowed_tabs) ? $tab : 'overview';

// Pre-fetch counts for tab badges (prepared statements)
$counts = [
    'victims' => 0,
    'suspects' => 0,
    'evidence' => 0,
    'documents' => 0,
    'arrests' => 0,
    'trials' => 0
];

try {
    // Victims (junction table victim_cases)
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM victim_cases WHERE case_id = ?");
    $stmt->execute([$case_id]);
    $counts['victims'] = (int)$stmt->fetchColumn();

    // Suspects (case_criminals where role_in_case indicates suspect or accomplice)
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM suspects WHERE case_id = ?");
    $stmt->execute([$case_id]);
    $counts['suspects'] = (int)$stmt->fetchColumn();

    // Evidence
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM evidence WHERE case_id = ?");
    $stmt->execute([$case_id]);
    $counts['evidence'] = (int)$stmt->fetchColumn();

    // Documents & attachments from media_files linked to this case
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM media_files WHERE related_type = 'Case' AND related_id = ?");
    $stmt->execute([$case_id]);
    $counts['documents'] = (int)$stmt->fetchColumn();

    // Arrests
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM arrests WHERE case_id = ?");
    $stmt->execute([$case_id]);
    $counts['arrests'] = (int)$stmt->fetchColumn();

    // Trials
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM trials WHERE case_id = ?");
    $stmt->execute([$case_id]);
    $counts['trials'] = (int)$stmt->fetchColumn();
} catch (PDOException $e) {
    // If any of these tables do not exist yet, counts remain zero.
    // Do not expose DB error on production page — log if needed.
}

// include header
include "../includes/header.php";
?>

<style>
/* Small, page-specific premium tweaks (hybrid theme) */
.case-hero { display:flex; gap:1rem; align-items:center; }
.case-hero .summary { background: var(--panel); padding:1rem; border-radius:10px; box-shadow: 0 8px 20px var(--card-shadow); flex:1; }
.case-meta { background: white; padding: 1rem; border-radius:10px; box-shadow: 0 8px 20px rgba(0,0,0,0.06); color: #111; }
.tab-badge { font-size: .75rem; padding: .2rem .5rem; border-radius: 999px; }
.small-muted { color: var(--muted); font-size: .9rem; }
.kv { display:flex; gap:.5rem; align-items:center; }
.kv strong { min-width:120px; display:inline-block; color:var(--muted); }
.section-card { background: var(--panel); padding:1rem; border-radius:8px; box-shadow: 0 6px 18px var(--card-shadow); color:inherit; }
.preview-list li { margin-bottom:.35rem; }
.nav-tabs .nav-link.active { font-weight:600; border-bottom:3px solid var(--accent); }
</style>

<div class="container mt-4">

    <div class="d-flex justify-content-between align-items-start mb-3">
        <div>
            <h4 class="mb-1">Case #<?= htmlspecialchars($case_id) ?> — <?= htmlspecialchars($case['title']) ?></h4>
            <div class="small-muted"> <?= htmlspecialchars($case['location'] ?: 'Location unknown') ?> · Created: <?= htmlspecialchars($case['case_date'] ?: '—') ?> </div>
        </div>

        <div class="d-flex gap-2">
            <?php if ($can_edit): ?>
                <a href="edit_case.php?id=<?= $case_id ?>" class="btn btn-warning">Edit Case</a>
            <?php endif; ?>
            <a href="list_cases.php" class="btn btn-outline-secondary">Back to Cases</a>
        </div>
    </div>

    <div class="case-hero mb-4">
        <div class="summary section-card">
            <div class="d-flex justify-content-between align-items-start">
                <div>
                    <h6 class="mb-1">Summary</h6>
                    <p class="small-muted mb-2"><?= nl2br(htmlspecialchars(mb_substr($case['description'] ?? 'No description', 0, 300))) ?><?= (strlen($case['description'] ?? '') > 300) ? '…' : '' ?></p>

                    <div class="row g-2">
                        <div class="col-md-6">
                            <div class="kv"><strong>Status:</strong> <span class="badge bg-<?= $case['status'] === 'Open' ? 'success' : ($case['status'] === 'Under Investigation' ? 'warning text-dark' : 'secondary') ?>"><?= htmlspecialchars($case['status']) ?></span></div>
                            <div class="kv"><strong>Assigned:</strong> <?= htmlspecialchars($case['officer_name'] ?: '—') ?></div>
                            <div class="kv"><strong>Department:</strong> <?= htmlspecialchars($case['dept_name'] ?: '—') ?></div>
                        </div>
                        <div class="col-md-6">
                            <div class="kv"><strong>Case Date:</strong> <?= htmlspecialchars($case['case_date'] ?: '—') ?></div>
                            <div class="kv"><strong>Last Updated:</strong> <?= htmlspecialchars($case['updated_at'] ?? $case['case_date'] ?? '—') ?></div>
                        </div>
                    </div>
                </div>

                <div class="text-end d-none d-md-block small">
                    <span class="badge bg-primary px-2 py-1 fs-7">
                        Victims: <?= (int)$counts['victims'] ?>
                    </span><br>

                    <span class="badge bg-warning text-dark px-2 py-1 fs-7 mt-1">
                        Suspects: <?= (int)$counts['suspects'] ?>
                    </span><br>

                    <span class="badge bg-danger px-2 py-1 fs-7 mt-1">
                        Arrests: <?= (int)$counts['arrests'] ?>
                    </span><br>

                    <span class="badge bg-info text-dark px-2 py-1 fs-7 mt-1">
                        Evidence: <?= (int)$counts['evidence'] ?>
                    </span><br>

                    <span class="badge bg-secondary px-2 py-1 fs-7 mt-1">
                        Documents: <?= (int)$counts['documents'] ?>
                    </span>
                </div>



            </div>
        </div>

        
    </div>

    <!-- Tabs -->
    <ul class="nav nav-tabs mb-3" role="tablist">
        <li class="nav-item"><a class="nav-link <?= $tab=='overview'?'active':'' ?>" href="?id=<?= $case_id ?>&tab=overview">Overview</a></li>
        <li class="nav-item"><a class="nav-link <?= $tab=='victims'?'active':'' ?>" href="?id=<?= $case_id ?>&tab=victims">Victims <span class="badge bg-secondary tab-badge ms-1"><?= $counts['victims'] ?></span></a></li>
        <li class="nav-item"><a class="nav-link <?= $tab=='suspects'?'active':'' ?>" href="?id=<?= $case_id ?>&tab=suspects">Suspects <span class="badge bg-secondary tab-badge ms-1"><?= $counts['suspects'] ?></span></a></li>
        <li class="nav-item"><a class="nav-link <?= $tab=='evidence'?'active':'' ?>" href="?id=<?= $case_id ?>&tab=evidence">Evidence <span class="badge bg-secondary tab-badge ms-1"><?= $counts['evidence'] ?></span></a></li>
        <li class="nav-item"><a class="nav-link <?= $tab=='documents'?'active':'' ?>" href="?id=<?= $case_id ?>&tab=documents">Documents <span class="badge bg-secondary tab-badge ms-1"><?= $counts['documents'] ?></span></a></li>
        <li class="nav-item"><a class="nav-link <?= $tab=='timeline'?'active':'' ?>" href="?id=<?= $case_id ?>&tab=timeline">Timeline</a></li>
        <li class="nav-item"><a class="nav-link <?= $tab=='arrests'?'active':'' ?>" href="?id=<?= $case_id ?>&tab=arrests">Arrests <span class="badge bg-secondary tab-badge ms-1"><?= $counts['arrests'] ?></span></a></li>
        <li class="nav-item"><a class="nav-link <?= $tab=='trials'?'active':'' ?>" href="?id=<?= $case_id ?>&tab=trials">Trials <span class="badge bg-secondary tab-badge ms-1"><?= $counts['trials'] ?></span></a></li>
    </ul>

    <!-- Tab contents (modular includes, fail-safe placeholders) -->
    <div>
        <?php
        // Build safe include path for tabs folder within cases/
        $tabs_dir = __DIR__ . '/tabs/';
        $tab_file = $tabs_dir . $tab . '.php';

        if (file_exists($tab_file)) {
            include $tab_file;
        } else {
            // Placeholder content when a tab file doesn't exist yet
            switch ($tab) {
                case 'overview':
                    ?>
                    <div class="section-card">
                        <h5 class="mb-2">Overview</h5>
                        <p class="small-muted">Full case description and metadata.</p>
                        <dl class="row">
                            <dt class="col-sm-3">Title</dt><dd class="col-sm-9"><?= htmlspecialchars($case['title']) ?></dd>
                            <dt class="col-sm-3">Description</dt><dd class="col-sm-9"><?= nl2br(htmlspecialchars($case['description'] ?: '—')) ?></dd>
                            <dt class="col-sm-3">Location</dt><dd class="col-sm-9"><?= htmlspecialchars($case['location'] ?: '—') ?></dd>
                            <dt class="col-sm-3">Status</dt><dd class="col-sm-9"><?= htmlspecialchars($case['status']) ?></dd>
                        </dl>
                    </div>
                    <?php
                    break;

                case 'victims':
                    ?>
                    <div class="section-card">
                        <h5>Victims</h5>
                        <p class="small-muted">Manage and view victims linked to this case. (Create <code>tabs/victims.php</code> to replace this.)</p>
                        <a class="btn btn-sm btn-dark mb-2" href="../victims/add_victim.php?case_id=<?= $case_id ?>">Add Victim</a>
                        <div class="alert alert-secondary">No victim UI installed yet.</div>
                    </div>
                    <?php
                    break;

                case 'suspects':
                    ?>
                    <div class="section-card">
                        <h5>Suspects</h5>
                        <p class="small-muted">Suspects / Persons of interest. (Create <code>tabs/suspects.php</code> to replace.)</p>
                        <a class="btn btn-sm btn-dark mb-2" href="../case_criminals/add.php?case_id=<?= $case_id ?>">Link Suspect</a>
                        <div class="alert alert-secondary">No suspects UI installed yet.</div>
                    </div>
                    <?php
                    break;

                case 'evidence':
                    ?>
                    <div class="section-card">
                        <h5>Evidence</h5>
                        <p class="small-muted">Photos, items, and digital evidence. (Create <code>tabs/evidence.php</code> to replace.)</p>
                        <a class="btn btn-sm btn-dark mb-2" href="../evidence/add_evidence.php?case_id=<?= $case_id ?>">Upload Evidence</a>
                        <div class="alert alert-secondary">No evidence UI installed yet.</div>
                    </div>
                    <?php
                    break;

                case 'documents':
                    ?>
                    <div class="section-card">
                        <h5>Documents</h5>
                        <p class="small-muted">Court documents, reports, and attachments.</p>
                        <a class="btn btn-sm btn-dark mb-2" href="../media/upload_media.php?type=Case&related_id=<?= $case_id ?>">Upload Document</a>
                        <div class="alert alert-secondary">No documents UI installed yet.</div>
                    </div>
                    <?php
                    break;

                case 'timeline':
                    ?>
                    <div class="section-card">
                        <h5>Timeline</h5>
                        <p class="small-muted">Chronological activity feed for the case.</p>
                        <div class="alert alert-secondary">No timeline UI installed yet.</div>
                    </div>
                    <?php
                    break;

                case 'arrests':
                    ?>
                    <div class="section-card">
                        <h5>Arrests</h5>
                        <p class="small-muted">Arrests related to this case.</p>
                        <a class="btn btn-sm btn-dark mb-2" href="../arrests/add_arrest.php?case_id=<?= $case_id ?>">Add Arrest</a>
                        <div class="alert alert-secondary">No arrests UI installed yet.</div>
                    </div>
                    <?php
                    break;

                case 'trials':
                    ?>
                    <div class="section-card">
                        <h5>Trials</h5>
                        <p class="small-muted">Court hearings & outcomes for this case.</p>
                        <a class="btn btn-sm btn-dark mb-2" href="../trials/add_trial.php?case_id=<?= $case_id ?>">Schedule Trial</a>
                        <div class="alert alert-secondary">No trials UI installed yet.</div>
                    </div>
                    <?php
                    break;

                default:
                    echo "<div class='alert alert-secondary'>Tab not implemented.</div>";
                    break;
            }
        }
        ?>
    </div>

</div>

<?php include "../includes/footer.php"; ?>

<?php if ($can_edit): ?>
<div class="modal fade" id="addArrestModal" tabindex="-1">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content rounded-4 shadow">

      <div class="modal-header">
        <h5 class="modal-title">Add Arrest</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <form action="arrests/add_arrest.php" method="POST">
        <input type="hidden" name="case_id" value="<?= $case_id ?>">

        <div class="modal-body">

            <div class="row g-3">

                <div class="col-md-6">
                    <label class="form-label">Criminal</label>
                    <select name="criminal_id" class="form-select" required>
                        <option value="">Select Criminal</option>
                        <?php foreach ($criminals as $c): ?>
                        <option value="<?= $c['criminal_id'] ?>">
                            <?= htmlspecialchars($c['name']) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Arrest Date</label>
                    <input type="date" name="arrest_date" class="form-control" required>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Arresting Officer</label>
                    <select name="arresting_officer_id" class="form-select">
                        <option value="">Select Officer</option>
                        <?php foreach ($officers as $o): ?>
                        <option value="<?= $o['officer_id'] ?>">
                            <?= htmlspecialchars($o['full_name']) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Custody Status</label>
                    <select name="custody_status" class="form-select">
                        <option value="In Custody">In Custody</option>
                        <option value="Released">Released</option>
                        <option value="Bail">Bail</option>
                    </select>
                </div>

            </div>

        </div>

        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Save Arrest</button>
        </div>

      </form>

    </div>
  </div>
</div>
<?php endif; ?>

<?php if ($can_edit): ?>
<div class="modal fade" id="addTrialModal" tabindex="-1">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content rounded-4 shadow">

      <div class="modal-header">
        <h5 class="modal-title">Add Trial</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <form action="trials/add_trial.php" method="POST">
        <input type="hidden" name="case_id" value="<?= $case_id ?>">

        <div class="modal-body">

          <div class="row g-3">

            <div class="col-md-6">
              <label class="form-label">Court Name</label>
              <input type="text" name="court_name" class="form-control" required>
            </div>

            <div class="col-md-6">
              <label class="form-label">Trial Date</label>
              <input type="date" name="trial_date" class="form-control">
            </div>

            <div class="col-md-6">
              <label class="form-label">Legal Representative</label>
              <input type="text" name="legal_representative" class="form-control">
            </div>

            <div class="col-md-6">
              <label class="form-label">Verdict</label>
              <select name="verdict" class="form-select">
                <option value="Pending">Pending</option>
                <option value="Guilty">Guilty</option>
                <option value="Not Guilty">Not Guilty</option>
              </select>
            </div>

            <div class="col-md-6">
              <label class="form-label">Appeal Status</label>
              <select name="appeal_status" class="form-select">
                <option value="Pending">Pending</option>
                <option value="Approved">Approved</option>
                <option value="Rejected">Rejected</option>
              </select>
            </div>

            <div class="col-12">
              <label class="form-label">Sentence Details</label>
              <textarea name="sentence_details" class="form-control" rows="3"></textarea>
            </div>

          </div>

        </div>

        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Save Trial</button>
        </div>

      </form>

    </div>
  </div>
</div>
<?php endif; ?>

<?php if ($can_edit): ?>
<div class="modal fade" id="addTrialModal" tabindex="-1">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content rounded-4 shadow">

      <div class="modal-header">
        <h5 class="modal-title">Add Trial</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <form action="trials/add_trial.php" method="POST">
        <input type="hidden" name="case_id" value="<?= $case_id ?>">

        <div class="modal-body">

          <div class="row g-3">

            <div class="col-md-6">
              <label class="form-label">Court Name</label>
              <input type="text" name="court_name" class="form-control" required>
            </div>

            <div class="col-md-6">
              <label class="form-label">Trial Date</label>
              <input type="date" name="trial_date" class="form-control">
            </div>

            <div class="col-md-6">
              <label class="form-label">Legal Representative</label>
              <input type="text" name="legal_representative" class="form-control">
            </div>

            <div class="col-md-6">
              <label class="form-label">Verdict</label>
              <select name="verdict" class="form-select">
                <option value="Pending">Pending</option>
                <option value="Guilty">Guilty</option>
                <option value="Not Guilty">Not Guilty</option>
              </select>
            </div>

            <div class="col-md-6">
              <label class="form-label">Appeal Status</label>
              <select name="appeal_status" class="form-select">
                <option value="Pending">Pending</option>
                <option value="Approved">Approved</option>
                <option value="Rejected">Rejected</option>
              </select>
            </div>

            <div class="col-12">
              <label class="form-label">Sentence Details</label>
              <textarea name="sentence_details" class="form-control" rows="3"></textarea>
            </div>

          </div>

        </div>

        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Save Trial</button>
        </div>

      </form>

    </div>
  </div>
</div>
<?php endif; ?>

<?php if ($can_edit): ?>
<div class="modal fade" id="uploadDocumentModal" tabindex="-1">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content rounded-4 shadow">

      <div class="modal-header">
        <h5 class="modal-title">Upload Document</h5>
        <button class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <form action="documents/upload_document.php" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="case_id" value="<?= $case_id ?>">

        <div class="modal-body">

            <div class="mb-3">
                <label class="form-label">Select File</label>

                <div class="border rounded-3 p-4 text-center bg-light" 
                     style="cursor:pointer"
                     onclick="document.getElementById('docFile').click()">

                    <i class="bi bi-cloud-arrow-up fs-1 text-secondary"></i>
                    <p class="mt-2 text-muted">Click to choose or drag & drop</p>

                    <input type="file" name="document" id="docFile" class="d-none" required>
                </div>
            </div>

        </div>

        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Upload</button>
        </div>

      </form>
    </div>
  </div>
</div>
<?php endif; ?>

<!-- ADD EVIDENCE MODAL -->
<div class="modal fade" id="addEvidenceModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <form action="evidence/add_evidence.php" method="POST" class="modal-content">
      
      <div class="modal-header">
        <h5 class="modal-title">Add Evidence</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">

        <input type="hidden" name="case_id" value="<?= $case_id ?>">

        <div class="mb-3">
            <label class="form-label">Description</label>
            <textarea name="description" class="form-control" required></textarea>
        </div>

        <div class="mb-3">
            <label class="form-label">Type</label>
            <select name="type" class="form-select">
                <option>Weapon</option>
                <option>Document</option>
                <option>Photo</option>
                <option>Digital</option>
                <option>Other</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Collected By (Officer)</label>
            <select name="collected_by" class="form-select">
                <option value="">—</option>
                <?php
                $officerList = $pdo->query("SELECT officer_id, name FROM officers ORDER BY name ASC");
                foreach ($officerList as $o):
                ?>
                <option value="<?= $o['officer_id'] ?>"><?= $o['name'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Date Collected</label>
            <input type="date" name="date_collected" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Status</label>
            <select name="status" class="form-select">
                <option>Submitted</option>
                <option>Analyzed</option>
                <option>Archived</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Chain of Custody (optional)</label>
            <textarea name="chain_of_custody" class="form-control"></textarea>
        </div>

      </div>

      <div class="modal-footer">
        <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-primary" type="submit">Save Evidence</button>
      </div>

    </form>
  </div>
</div>

<?php if ($can_edit): ?>
<!-- EDIT ARREST MODAL -->
<div class="modal fade" id="editArrestModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <form action="arrests/edit_arrest.php" method="POST" class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title">Edit Arrest</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">

        <input type="hidden" name="arrest_id" id="editArrestId" value="">
        <input type="hidden" name="case_id" value="<?= $case_id ?>">

        <div class="mb-3">
            <label class="form-label">Criminal</label>
            <select name="criminal_id" id="editCriminalId" class="form-select" required>
                <option value="">Select Criminal</option>
                <?php
                $criminalList = $pdo->query("SELECT criminal_id, name FROM criminals ORDER BY name ASC");
                foreach ($criminalList as $c):
                ?>
                <option value="<?= $c['criminal_id'] ?>"><?= htmlspecialchars($c['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Arrest Date</label>
            <input type="date" name="arrest_date" id="editArrestDate" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Arresting Officer</label>
            <select name="arresting_officer_id" id="editOfficerId" class="form-select">
                <option value="">—</option>
                <?php
                $officerList = $pdo->query("SELECT officer_id, name FROM officers ORDER BY name ASC");
                foreach ($officerList as $o):
                ?>
                <option value="<?= $o['officer_id'] ?>"><?= htmlspecialchars($o['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Custody Status</label>
            <select name="custody_status" id="editCustodyStatus" class="form-select">
                <option value="In Custody">In Custody</option>
                <option value="Released">Released</option>
                <option value="Bail">Bail</option>
            </select>
        </div>

      </div>

      <div class="modal-footer">
        <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-primary" type="submit">Update Arrest</button>
      </div>

    </form>
  </div>
</div>

<!-- Script to populate modal with data -->
<script>
function openEditArrestModal(arrest) {
    const modal = new bootstrap.Modal(document.getElementById('editArrestModal'));
    document.getElementById('editArrestId').value = arrest.arrest_id;
    document.getElementById('editCriminalId').value = arrest.criminal_id;
    document.getElementById('editArrestDate').value = arrest.arrest_date;
    document.getElementById('editOfficerId').value = arrest.arresting_officer_id || '';
    document.getElementById('editCustodyStatus').value = arrest.custody_status;
    modal.show();
}
</script>
<?php endif; ?>
