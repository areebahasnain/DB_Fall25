<?php
// /cases/edit_case.php
require_once "../config/database.php";
require_once "../includes/functions.php";
require_once "../includes/auth.php";

if (!isset($_GET['id'])) {
    redirect("list_cases.php");
}

$case_id = (int)$_GET['id'];

// Fetch existing case
$stmt = $pdo->prepare("SELECT * FROM cases WHERE case_id = ?");
$stmt->execute([$case_id]);
$case = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$case) {
    redirect("list_cases.php");
}

$errors = [];
$title = $case['title'];
$description = $case['description'];
$location = $case['location'];
$case_date = $case['case_date'];
$status = $case['status'];
$assigned_officer_id = $case['assigned_officer_id'];
$department_id = $case['department_id'];
$priority = $case['priority'] ?? 'Low';

// Fetch officers and departments for dropdowns
$officers = $pdo->query("
    SELECT o.officer_id, u.full_name AS name
    FROM officers o
    JOIN users u ON o.user_id = u.user_id
    ORDER BY u.full_name ASC
")->fetchAll(PDO::FETCH_ASSOC);
$departments = $pdo->query("SELECT department_id, name FROM departments ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $location = trim($_POST['location'] ?? '');
    $case_date = $_POST['case_date'] ?: null;
    $status = $_POST['status'] ?? 'Open';
    $assigned_officer_id = $_POST['assigned_officer_id'] ?: null;
    $department_id = $_POST['department_id'] ?: null;
    $priority = $_POST['priority'] ?? 'Low';

    if (!$title) {
        $errors[] = "Title is required.";
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare("
            UPDATE cases 
            SET title = ?, description = ?, location = ?, case_date = ?, status = ?, assigned_officer_id = ?, department_id = ?, priority = ?
            WHERE case_id = ?
        ");
        $stmt->execute([
            $title,
            $description,
            $location,
            $case_date,
            $status,
            $assigned_officer_id,
            $department_id,
            $priority,
            $case_id
        ]);

        // Log edit to timeline
        require_once "../includes/functions_timeline.php";
        log_case_event($case_id, "Case updated", "Case details were edited.", 'Case', $_SESSION['user_id']);
        redirect("view_case.php?id=" . $case_id);
    }
}

include "../includes/header.php";
?>

<div class="container mt-4">
    <h4>Edit Case #<?= htmlspecialchars($case_id) ?></h4>

    <?php if ($errors): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach ($errors as $e): ?>
                    <li><?= htmlspecialchars($e) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST">
        <div class="mb-3">
            <label class="form-label">Title *</label>
            <input type="text" name="title" class="form-control" value="<?= htmlspecialchars($title) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Description</label>
            <textarea name="description" class="form-control"><?= htmlspecialchars($description) ?></textarea>
        </div>

        <div class="mb-3">
            <label class="form-label">Location</label>
            <input type="text" name="location" class="form-control" value="<?= htmlspecialchars($location) ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Case Date</label>
            <input type="date" name="case_date" class="form-control" value="<?= htmlspecialchars($case_date) ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Status</label>
            <select name="status" class="form-select">
                <option value="Open" <?= $status=='Open'?'selected':'' ?>>Open</option>
                <option value="Under Investigation" <?= $status=='Under Investigation'?'selected':'' ?>>Under Investigation</option>
                <option value="Closed" <?= $status=='Closed'?'selected':'' ?>>Closed</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Priority</label>
            <select name="priority" class="form-select">
                <option value="High" <?= $priority=='High'?'selected':'' ?>>High</option>
                <option value="Medium" <?= $priority=='Medium'?'selected':'' ?>>Medium</option>
                <option value="Low" <?= $priority=='Low'?'selected':'' ?>>Low</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Assigned Officer</label>
            <select name="assigned_officer_id" class="form-select">
                <option value="">— None —</option>
                <?php foreach ($officers as $o): ?>
                    <option value="<?= $o['officer_id'] ?>" <?= $assigned_officer_id == $o['officer_id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($o['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Department</label>
            <select name="department_id" class="form-select">
                <option value="">— None —</option>
                <?php foreach ($departments as $d): ?>
                    <option value="<?= $d['department_id'] ?>" <?= $department_id == $d['department_id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($d['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <button class="btn btn-primary" type="submit">Update Case</button>
        <a href="view_case.php?id=<?= $case_id ?>" class="btn btn-outline-secondary">Cancel</a>
    </form>
</div>

<?php include "../includes/footer.php"; ?>
