<?php
// /cases/tabs/victims.php

$role = $_SESSION['role'] ?? 'Analyst';
$isAdmin = $role === 'Admin';
$isOfficer = $role === 'Officer';
$canEdit = ($isAdmin || $isOfficer);

// Fetch victims linked to this case
$stmt = $pdo->prepare("
    SELECT v.*, vc.role_in_case
    FROM victim_cases vc
    INNER JOIN victims v ON vc.victim_id = v.victim_id
    WHERE vc.case_id = ?
    ORDER BY v.full_name ASC
");
$stmt->execute([$case_id]);
$victims = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">Victims</h5>

    <?php if ($canEdit): ?>
    <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addVictimModal">
        <i class="bi bi-person-plus"></i> Add Victim
    </button>
    <?php endif; ?>
</div>

<?php if (empty($victims)): ?>
<div class="alert alert-info">No victims linked to this case yet.</div>
<?php else: ?>
<div class="row g-3">
<?php foreach ($victims as $v): ?>
<div class="col-md-4">
    <div class="card shadow-sm h-100">
        <div class="card-body">
            <h6 class="fw-bold mb-1"><?= htmlspecialchars($v['full_name']) ?></h6>
            <?php if ($v['dob']): ?>
            <small><i class="bi bi-calendar"></i> DOB: <?= htmlspecialchars($v['dob']) ?></small><br>
            <?php endif; ?>
            <?php if ($v['gender']): ?>
            <small>Gender: <?= htmlspecialchars($v['gender']) ?></small><br>
            <?php endif; ?>
            <?php if ($v['contact']): ?>
            <small><i class="bi bi-telephone"></i> <?= htmlspecialchars($v['contact']) ?></small><br>
            <?php endif; ?>
            <?php if ($v['address']): ?>
            <small><i class="bi bi-geo-alt"></i> <?= htmlspecialchars($v['address']) ?></small>
            <?php endif; ?>
            <br>
        </div>

        <?php if ($canEdit): ?>
        <!-- Footer with left-aligned Edit/Delete buttons -->
        <div class="card-footer d-flex justify-content-start gap-2">
            <button class="btn btn-sm btn-outline-primary"
                    data-bs-toggle="modal"
                    data-bs-target="#editVictim<?= $v['victim_id'] ?>">
                Edit
            </button>

            <button class="btn btn-sm btn-outline-danger"
                    data-bs-toggle="modal"
                    data-bs-target="#deleteVictim<?= $v['victim_id'] ?>">
                Delete
            </button>
        </div>
        <?php endif; ?>

    </div>
</div>

<!-- EDIT MODAL -->
<?php if ($canEdit): ?>
<div class="modal fade" id="editVictim<?= $v['victim_id'] ?>" tabindex="-1">
  <div class="modal-dialog">
    <form action="/CRIME_ANALYTICS/cases/victims/edit_victim.php" method="POST" class="modal-content">

      <input type="hidden" name="victim_id" value="<?= $v['victim_id'] ?>">
      <input type="hidden" name="case_id" value="<?= $case_id ?>">

      <div class="modal-header">
        <h5 class="modal-title">Edit Victim</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">
        <div class="mb-3">
          <label class="form-label">Full Name</label>
          <input type="text" name="full_name" class="form-control" required
                 value="<?= htmlspecialchars($v['full_name']) ?>">
        </div>

        <div class="mb-3">
          <label class="form-label">DOB</label>
          <input type="date" name="dob" class="form-control" value="<?= htmlspecialchars($v['dob']) ?>">
        </div>

        <div class="mb-3">
          <label class="form-label">Gender</label>
          <select name="gender" class="form-select">
            <option value="">Select</option>
            <option value="Male" <?= $v['gender']=='Male'?'selected':'' ?>>Male</option>
            <option value="Female" <?= $v['gender']=='Female'?'selected':'' ?>>Female</option>
            <option value="Other" <?= $v['gender']=='Other'?'selected':'' ?>>Other</option>
          </select>
        </div>

        <div class="mb-3">
          <label class="form-label">Contact</label>
          <input type="text" name="contact" class="form-control" value="<?= htmlspecialchars($v['contact']) ?>">
        </div>

        <div class="mb-3">
          <label class="form-label">Address</label>
          <textarea name="address" class="form-control"><?= htmlspecialchars($v['address']) ?></textarea>
        </div>

        <div class="mb-3">
          <label class="form-label">Role in Case</label>
          <input type="text" name="role_in_case" class="form-control" value="<?= htmlspecialchars($v['role_in_case']) ?>">
        </div>

      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-primary">Save Changes</button>
      </div>

    </form>
  </div>
</div>

<!-- DELETE MODAL -->
<div class="modal fade" id="deleteVictim<?= $v['victim_id'] ?>" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">

      <div class="modal-header bg-danger text-white">
        <h5 class="modal-title">Delete Victim</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">
        <p>Are you sure you want to delete:</p>
        <p class="fw-bold text-danger"><?= htmlspecialchars($v['full_name']) ?></p>
        <p>This action cannot be undone.</p>
      </div>

      <div class="modal-footer">
        <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>

        <a href="/CRIME_ANALYTICS/cases/victims/delete_victim.php?victim_id=<?= $v['victim_id'] ?>&case_id=<?= $case_id ?>"
           class="btn btn-danger">
          Delete
        </a>
      </div>

    </div>
  </div>
</div>
<?php endif; ?>

<?php endforeach; ?>
</div>
<?php endif; ?>


<!-- ADD VICTIM MODAL -->
<?php if ($canEdit): ?>
<div class="modal fade" id="addVictimModal" tabindex="-1">
  <div class="modal-dialog">
    <form action="/CRIME_ANALYTICS/cases/victims/add_victim.php" method="POST" class="modal-content">

      <input type="hidden" name="case_id" value="<?= $case_id ?>">

      <div class="modal-header">
        <h5 class="modal-title">Add Victim</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">
        <div class="mb-3">
          <label class="form-label">Full Name</label>
          <input type="text" name="full_name" class="form-control" required>
        </div>

        <div class="mb-3">
          <label class="form-label">DOB</label>
          <input type="date" name="dob" class="form-control">
        </div>

        <div class="mb-3">
          <label class="form-label">Gender</label>
          <select name="gender" class="form-select">
            <option value="">Select</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
          </select>
        </div>

        <div class="mb-3">
          <label class="form-label">Contact</label>
          <input type="text" name="contact" class="form-control">
        </div>

        <div class="mb-3">
          <label class="form-label">Address</label>
          <textarea name="address" class="form-control"></textarea>
        </div>

      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-primary">Add Victim</button>
      </div>

    </form>
  </div>
</div>
<?php endif; ?>
