<?php
// trials.php

$role = $_SESSION['role'] ?? 'Analyst';
$isAdmin = $role === 'Admin';
$isOfficer = $role === 'Officer';
$canEdit = ($isAdmin || $isOfficer);

$stmt = $pdo->prepare("
    SELECT * FROM trials
    WHERE case_id = ?
    ORDER BY trial_date DESC
");
$stmt->execute([$case_id]);
$trials = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">Trials</h5>

    <?php if ($canEdit): ?>
    <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addTrialModal">
        <i class="bi bi-plus-circle"></i> Add Trial
    </button>
    <?php endif; ?>
</div>

<?php if (empty($trials)): ?>
<div class="alert alert-info">No trial records added yet.</div>
<?php else: ?>

<div class="row g-3">

<?php foreach ($trials as $t): ?>
<div class="col-md-4">
    <div class="card shadow-sm h-100">

        <div class="card-body">
            <h6 class="fw-bold mb-2"><?= htmlspecialchars($t['court_name']) ?></h6>

            <small><i class="bi bi-calendar"></i> 
                Trial Date: <?= htmlspecialchars($t['trial_date']) ?>
            </small><br>

            <small><i class="bi bi-balance-scale"></i>
                Verdict: <?= htmlspecialchars($t['verdict']) ?>
            </small><br>

            <small><i class="bi bi-file-text"></i>
                Appeal Status: <?= htmlspecialchars($t['appeal_status']) ?>
            </small>
        </div>

        <div class="card-footer d-flex justify-content-between">
            <button class="btn btn-sm btn-outline-secondary"
                    data-bs-toggle="modal"
                    data-bs-target="#viewTrial<?= $t['trial_id'] ?>">
                View
            </button>

            <?php if ($canEdit): ?>
            <button class="btn btn-sm btn-outline-primary"
                    data-bs-toggle="modal"
                    data-bs-target="#editTrial<?= $t['trial_id'] ?>">
                Edit
            </button>
            <?php endif; ?>
        </div>

    </div>
</div>

<!-- VIEW TRIAL MODAL -->
<div class="modal fade" id="viewTrial<?= $t['trial_id'] ?>" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

        <div class="modal-header">
            <h5 class="modal-title">Trial Details</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>

        <div class="modal-body">
            <p><strong>Court Name:</strong> <?= htmlspecialchars($t['court_name']) ?></p>
            <p><strong>Trial Date:</strong> <?= htmlspecialchars($t['trial_date']) ?></p>
            <p><strong>Verdict:</strong> <?= htmlspecialchars($t['verdict']) ?></p>
            <p><strong>Legal Representative:</strong> <?= htmlspecialchars($t['legal_representative']) ?></p>
            <p><strong>Appeal Status:</strong> <?= htmlspecialchars($t['appeal_status']) ?></p>
            <p><strong>Sentence Details:</strong><br>
                <?= nl2br(htmlspecialchars($t['sentence_details'])) ?>
            </p>
        </div>

        <div class="modal-footer">
            <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        </div>

    </div>
  </div>
</div>

<!-- EDIT TRIAL MODAL -->
<?php if ($canEdit): ?>
<div class="modal fade" id="editTrial<?= $t['trial_id'] ?>" tabindex="-1">
  <div class="modal-dialog">
    <form action="trials/edit_trial.php" method="POST" class="modal-content">

        <input type="hidden" name="trial_id" value="<?= $t['trial_id'] ?>">
        <input type="hidden" name="case_id" value="<?= $case_id ?>">

        <div class="modal-header">
            <h5 class="modal-title">Edit Trial</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>

        <div class="modal-body">

            <div class="mb-3">
                <label class="form-label">Court Name</label>
                <input type="text" name="court_name" class="form-control" required
                       value="<?= htmlspecialchars($t['court_name']) ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">Trial Date</label>
                <input type="date" name="trial_date" class="form-control"
                       value="<?= htmlspecialchars($t['trial_date']) ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">Verdict</label>
                <select name="verdict" class="form-select">
                    <option value="Pending" <?= $t['verdict']=='Pending'?'selected':'' ?>>Pending</option>
                    <option value="Guilty" <?= $t['verdict']=='Guilty'?'selected':'' ?>>Guilty</option>
                    <option value="Not Guilty" <?= $t['verdict']=='Not Guilty'?'selected':'' ?>>Not Guilty</option>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Legal Representative</label>
                <input type="text" name="legal_representative" class="form-control"
                       value="<?= htmlspecialchars($t['legal_representative']) ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">Appeal Status</label>
                <select name="appeal_status" class="form-select">
                    <option value="Pending" <?= $t['appeal_status']=='Pending'?'selected':'' ?>>Pending</option>
                    <option value="Approved" <?= $t['appeal_status']=='Approved'?'selected':'' ?>>Approved</option>
                    <option value="Rejected" <?= $t['appeal_status']=='Rejected'?'selected':'' ?>>Rejected</option>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Sentence Details</label>
                <textarea name="sentence_details" class="form-control" rows="3"><?= htmlspecialchars($t['sentence_details']) ?></textarea>
            </div>

        </div>

        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            <button class="btn btn-primary">Save Changes</button>
        </div>

    </form>
  </div>
</div>
<?php endif; ?>

<?php endforeach; ?>
</div>

<?php endif; ?>

<!-- ADD TRIAL MODAL -->
<?php if ($canEdit): ?>
<div class="modal fade" id="addTrialModal" tabindex="-1">
  <div class="modal-dialog">
    <form action="trials/add_trial.php" method="POST" class="modal-content">

        <input type="hidden" name="case_id" value="<?= $case_id ?>">

        <div class="modal-header">
            <h5 class="modal-title">Add Trial</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>

        <div class="modal-body">

            <div class="mb-3">
                <label class="form-label">Court Name</label>
                <input type="text" name="court_name" class="form-control" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Trial Date</label>
                <input type="date" name="trial_date" class="form-control">
            </div>

            <div class="mb-3">
                <label class="form-label">Verdict</label>
                <select name="verdict" class="form-select">
                    <option value="Pending">Pending</option>
                    <option value="Guilty">Guilty</option>
                    <option value="Not Guilty">Not Guilty</option>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Legal Representative</label>
                <input type="text" name="legal_representative" class="form-control">
            </div>

            <div class="mb-3">
                <label class="form-label">Appeal Status</label>
                <select name="appeal_status" class="form-select">
                    <option value="Pending">Pending</option>
                    <option value="Approved">Approved</option>
                    <option value="Rejected">Rejected</option>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Sentence Details</label>
                <textarea name="sentence_details" class="form-control" rows="3"></textarea>
            </div>

        </div>

        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            <button class="btn btn-primary">Add Trial</button>
        </div>

    </form>
  </div>
</div>
<?php endif; ?>
