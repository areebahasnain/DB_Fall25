<?php
// Fetch arrests for this case
$arrestStmt = $pdo->prepare("
    SELECT a.*, 
           c.full_name AS criminal_name,
           o_user.full_name AS arresting_officer_name
    FROM arrests a
    LEFT JOIN criminals c ON a.criminal_id = c.criminal_id
    LEFT JOIN officers o ON a.arresting_officer_id = o.officer_id
    LEFT JOIN users o_user ON o.user_id = o_user.user_id
    WHERE a.case_id = ?
    ORDER BY a.arrest_date DESC
");
$arrestStmt->execute([$case_id]);
$arrests = $arrestStmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch criminals for dropdown
$criminals = $pdo->query("
    SELECT criminal_id, full_name
    FROM criminals
    ORDER BY full_name ASC
")->fetchAll(PDO::FETCH_ASSOC);

// Fetch officers for dropdown
$officers = $pdo->query("
    SELECT o.officer_id, u.full_name
    FROM officers o
    LEFT JOIN users u ON o.user_id = u.user_id
    ORDER BY u.full_name ASC
")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="tab-pane fade <?= $tab=='arrests' ? 'show active' : '' ?>" id="arrests" role="tabpanel" aria-labelledby="arrests-tab">

<!-- Success/Error Alerts -->
<?php if (!empty($_SESSION['success'])): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?= $_SESSION['success'] ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php unset($_SESSION['success']); endif; ?>

<?php if (!empty($_SESSION['error'])): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <?= $_SESSION['error'] ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php unset($_SESSION['error']); endif; ?>

<!-- Header & Add button -->
<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">Arrests</h5>
    <?php if ($can_edit): ?>
    <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addArrestModal">
        <i class="bi bi-plus-circle me-1"></i> Add Arrest
    </button>
    <?php endif; ?>
</div>

<?php if (empty($arrests)): ?>
    <div class="alert alert-info">No arrests recorded for this case.</div>
<?php else: ?>
<div class="row g-3">
<?php foreach ($arrests as $arrest): ?>
    <div class="col-md-6 mb-3">
        <div class="card shadow-sm border-0 rounded-4">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <h6 class="fw-bold mb-1">Arrest #<?= $arrest['arrest_id'] ?> (Case #<?= $arrest['case_id'] ?>)</h6>
                    </div>
                    <div class="d-flex gap-2">
                        <!-- View Button -->
                        <button class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#viewArrestModal<?= $arrest['arrest_id'] ?>">View</button>

                        <?php if ($can_edit): ?>
                        <!-- Edit Button -->
                        <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#editArrestModal<?= $arrest['arrest_id'] ?>">
                            <i class="bi bi-pencil"></i>
                        </button>
                        <!-- Delete Button -->
                        <button class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteArrestModal<?= $arrest['arrest_id'] ?>">
                            <i class="bi bi-trash"></i>
                        </button>
                        <?php endif; ?>
                    </div>
                </div>

                <p class="text-muted small mb-2"><?= $arrest['arrest_date'] ? date("F j, Y", strtotime($arrest['arrest_date'])) : '—' ?></p>
                <p class="mb-1"><strong>Criminal:</strong> <?= htmlspecialchars($arrest['criminal_name']) ?></p>
                <p class="mb-1"><strong>Arresting Officer:</strong> <?= $arrest['arresting_officer_name'] ?: 'N/A' ?></p>
                <p class="mb-1"><strong>Custody Status:</strong>
                    <span class="badge <?= $arrest['custody_status'] === 'In Custody' ? 'bg-success' : ($arrest['custody_status'] === 'Bail' ? 'bg-warning text-dark' : 'bg-secondary') ?>">
                        <?= htmlspecialchars($arrest['custody_status']) ?>
                    </span>
                </p>
            </div>
        </div>
    </div>

    <!-- VIEW Arrest Modal -->
    <div class="modal fade" id="viewArrestModal<?= $arrest['arrest_id'] ?>" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Arrest #<?= $arrest['arrest_id'] ?> Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p><strong>Criminal:</strong> <?= htmlspecialchars($arrest['criminal_name']) ?></p>
                    <p><strong>Arresting Officer:</strong> <?= $arrest['arresting_officer_name'] ?: 'N/A' ?></p>
                    <p><strong>Arrest Date:</strong> <?= $arrest['arrest_date'] ? date("F j, Y", strtotime($arrest['arrest_date'])) : '—' ?></p>
                    <p><strong>Custody Status:</strong> <?= htmlspecialchars($arrest['custody_status']) ?></p>
                    <p><strong>Case ID:</strong> <?= $case_id ?></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- EDIT Arrest Modal -->
    <div class="modal fade" id="editArrestModal<?= $arrest['arrest_id'] ?>" tabindex="-1">
      <div class="modal-dialog modal-lg">
        <form action="arrests/edit_arrest.php" method="POST" class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Edit Arrest #<?= $arrest['arrest_id'] ?></h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <input type="hidden" name="arrest_id" value="<?= $arrest['arrest_id'] ?>">
            <input type="hidden" name="case_id" value="<?= $arrest['case_id'] ?>">

            <div class="mb-3">
                <label class="form-label">Criminal</label>
                <select name="criminal_id" class="form-select" required>
                    <option value="">Select Criminal</option>
                    <?php foreach ($criminals as $c): ?>
                    <option value="<?= $c['criminal_id'] ?>" <?= $c['criminal_id']==$arrest['criminal_id']?'selected':'' ?>>
                        <?= htmlspecialchars($c['name']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Arrest Date</label>
                <input type="date" name="arrest_date" class="form-control" value="<?= $arrest['arrest_date'] ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Arresting Officer</label>
                <select name="arresting_officer_id" class="form-select">
                    <option value="">—</option>
                    <?php foreach ($officers as $o): ?>
                    <option value="<?= $o['officer_id'] ?>" <?= $o['officer_id']==$arrest['arresting_officer_id']?'selected':'' ?>>
                        <?= htmlspecialchars($o['full_name']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Custody Status</label>
                <select name="custody_status" class="form-select">
                    <option value="In Custody" <?= $arrest['custody_status']=='In Custody'?'selected':'' ?>>In Custody</option>
                    <option value="Released" <?= $arrest['custody_status']=='Released'?'selected':'' ?>>Released</option>
                    <option value="Bail" <?= $arrest['custody_status']=='Bail'?'selected':'' ?>>Bail</option>
                </select>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary">Save Changes</button>
          </div>
        </form>
      </div>
    </div>

    <!-- DELETE Arrest Modal -->
    <div class="modal fade" id="deleteArrestModal<?= $arrest['arrest_id'] ?>" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="arrests/delete_arrest.php" method="GET">
                    <input type="hidden" name="arrest_id" value="<?= $arrest['arrest_id'] ?>">
                    <input type="hidden" name="case_id" value="<?= $case_id ?>">
                    <div class="modal-header">
                        <h5 class="modal-title">Delete Arrest #<?= $arrest['arrest_id'] ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        Are you sure you want to delete this arrest record?
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php endforeach; ?>
</div>
<?php endif; ?>

<!-- ADD Arrest Modal -->
<?php if ($can_edit): ?>
<div class="modal fade" id="addArrestModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <form action="arrests/add_arrest.php" method="POST" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Add Arrest</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" name="case_id" value="<?= $case_id ?>">

        <div class="mb-3">
            <label class="form-label">Criminal</label>
            <select name="criminal_id" class="form-select" required>
                <option value="">Select Criminal</option>
                <?php foreach ($criminals as $c): ?>
                <option value="<?= $c['criminal_id'] ?>"><?= htmlspecialchars($c['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Arrest Date</label>
            <input type="date" name="arrest_date" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Arresting Officer</label>
            <select name="arresting_officer_id" class="form-select">
                <option value="">—</option>
                <?php foreach ($officers as $o): ?>
                <option value="<?= $o['officer_id'] ?>"><?= htmlspecialchars($o['full_name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Custody Status</label>
            <select name="custody_status" class="form-select">
                <option value="In Custody">In Custody</option>
                <option value="Released">Released</option>
                <option value="Bail">Bail</option>
            </select>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-primary" type="submit">Add Arrest</button>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>
