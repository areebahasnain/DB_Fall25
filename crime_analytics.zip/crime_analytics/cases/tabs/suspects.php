<?php
// /cases/tabs/suspects.php

$role = $_SESSION['role'] ?? 'Analyst';
$isAdmin = $role === 'Admin';
$isOfficer = $role === 'Officer';
$canEdit = ($isAdmin || $isOfficer);

$stmt = $pdo->prepare("
    SELECT s.*, c.full_name AS criminal_name
    FROM suspects s
    LEFT JOIN criminals c ON s.criminal_id = c.criminal_id
    WHERE s.case_id = ?
    ORDER BY s.added_at DESC
");
$stmt->execute([$case_id]);
$suspects = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">Suspects</h5>
    <?php if ($canEdit): ?>
    <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addSuspectModal">
        <i class="bi bi-person-plus"></i> Add Suspect
    </button>
    <?php endif; ?>
</div>

<?php if (empty($suspects)): ?>
    <div class="alert alert-info">No suspects added for this case yet.</div>
<?php else: ?>
<div class="row g-3">
<?php foreach ($suspects as $s): ?>
    <div class="col-md-4">
        <div class="card shadow-sm h-100">
            <div class="card-body">
                <h6 class="fw-bold mb-1"><?= htmlspecialchars($s['name']) ?></h6>

                <?php if ($s['criminal_id']): ?>
                <small class="text-muted">Linked Criminal: <?= htmlspecialchars($s['criminal_name']) ?></small><br>
                <?php endif; ?>

                <?php if ($s['contact_number']): ?>
                <small><i class="bi bi-telephone"></i> <?= htmlspecialchars($s['contact_number']) ?></small><br>
                <?php endif; ?>

                <?php if ($s['email']): ?>
                <small><i class="bi bi-envelope"></i> <?= htmlspecialchars($s['email']) ?></small><br>
                <?php endif; ?>

                <?php if ($s['address']): ?>
                <small><i class="bi bi-geo-alt"></i> <?= htmlspecialchars($s['address']) ?></small>
                <?php endif; ?>
            </div>

            <?php if ($canEdit): ?>
            <!-- Footer with left-aligned buttons -->
            <div class="card-footer d-flex justify-content-start gap-2">
                <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#editSuspectModal<?= $s['suspect_id'] ?>">Edit</button>
                <a href="suspects/delete_suspect.php?suspect_id=<?= $s['suspect_id'] ?>&case_id=<?= $case_id ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this suspect?');">Delete</a>
            </div>

            <?php endif; ?>
        </div>
    </div>

    <!-- EDIT SUSPECT MODAL -->
    <?php if ($canEdit): ?>
    <div class="modal fade" id="editSuspectModal<?= $s['suspect_id'] ?>" tabindex="-1">
        <div class="modal-dialog">
            <form action="suspects/edit_suspect.php" method="POST" class="modal-content">
                <input type="hidden" name="suspect_id" value="<?= $s['suspect_id'] ?>">
                <input type="hidden" name="case_id" value="<?= $case_id ?>">

                <div class="modal-header">
                    <h5 class="modal-title">Edit Suspect</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Full Name</label>
                        <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($s['name']) ?>" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Linked Criminal (optional)</label>
                        <select name="criminal_id" class="form-select">
                            <option value="">— None —</option>
                            <?php
                            $cr = $pdo->query("SELECT criminal_id, full_name FROM criminals ORDER BY full_name")->fetchAll();
                            foreach ($cr as $c):
                            ?>
                            <option value="<?= $c['criminal_id'] ?>" <?= $s['criminal_id']==$c['criminal_id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($c['full_name']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Contact Number</label>
                        <input type="text" name="contact_number" class="form-control" value="<?= htmlspecialchars($s['contact_number']) ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($s['email']) ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Address</label>
                        <textarea name="address" class="form-control"><?= htmlspecialchars($s['address']) ?></textarea>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>

<?php endforeach; ?>
</div>
<?php endif; ?>

<!-- ADD SUSPECT MODAL -->
<?php if ($canEdit): ?>
<div class="modal fade" id="addSuspectModal" tabindex="-1">
    <div class="modal-dialog">
        <form action="suspects/add_suspect.php" method="POST" class="modal-content">
            <input type="hidden" name="case_id" value="<?= $case_id ?>">

            <div class="modal-header">
                <h5 class="modal-title">Add Suspect</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label">Full Name</label>
                    <input type="text" name="name" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Linked Criminal (optional)</label>
                    <select name="criminal_id" class="form-select">
                        <option value="">— None —</option>
                        <?php
                        $crim = $pdo->query("SELECT criminal_id, full_name FROM criminals ORDER BY full_name")->fetchAll();
                        foreach ($crim as $c):
                        ?>
                        <option value="<?= $c['criminal_id'] ?>"><?= htmlspecialchars($c['full_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">Contact Number</label>
                    <input type="text" name="contact_number" class="form-control">
                </div>

                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control">
                </div>

                <div class="mb-3">
                    <label class="form-label">Address</label>
                    <textarea name="address" class="form-control"></textarea>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button class="btn btn-primary">Add Suspect</button>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>
