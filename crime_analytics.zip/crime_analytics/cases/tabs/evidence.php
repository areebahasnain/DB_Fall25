<?php
// Fetch evidence for this case
$evidenceStmt = $pdo->prepare("
    SELECT 
        e.*, 
        u.full_name AS collected_by_name
    FROM evidence e
    LEFT JOIN officers o ON e.collected_by = o.officer_id
    LEFT JOIN users u ON o.user_id = u.user_id
    WHERE e.case_id = ?
    ORDER BY e.date_collected DESC
");
$evidenceStmt->execute([$case_id]);
$evidences = $evidenceStmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch officers for dropdown
$officers = $pdo->query("
    SELECT 
        o.officer_id,
        u.full_name
    FROM officers o
    JOIN users u ON o.user_id = u.user_id
    ORDER BY u.full_name ASC
")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="tab-pane fade <?= $tab=='evidence'?'show active':'' ?>" id="evidence" role="tabpanel" aria-labelledby="evidence-tab">

<?php if (!empty($_SESSION['success'])): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?= $_SESSION['success'] ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php unset($_SESSION['success']); endif; ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">Evidence</h5>
    <?php if ($can_edit): ?>
    <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addEvidenceModal">
        <i class="bi bi-plus-circle me-1"></i> Add Evidence
    </button>
    <?php endif; ?>
</div>

<?php if (empty($evidences)): ?>
    <div class="alert alert-info">No evidence recorded for this case.</div>
<?php else: ?>
<div class="row g-3">
<?php foreach ($evidences as $ev): ?>
    <div class="col-md-6 mb-3">
        <div class="card shadow-sm border-0 rounded-4">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <h6 class="fw-bold mb-1">Evidence #<?= $ev['evidence_id'] ?> (Case #<?= $ev['case_id'] ?>)</h6>
                    <?php if ($can_edit): ?>
                    <div class="btn-group btn-group-sm">
                        <!-- View Modal Trigger -->
                        <button class="btn btn-outline-info" data-bs-toggle="modal" data-bs-target="#viewEvidenceModal<?= $ev['evidence_id'] ?>">
                            <i class="bi bi-eye"></i>
                        </button>
                        <!-- Edit Modal Trigger -->
                        <button class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#editEvidenceModal<?= $ev['evidence_id'] ?>">
                            <i class="bi bi-pencil"></i>
                        </button>
                        <!-- Delete -->
                        <a href="evidence/delete_evidence.php?evidence_id=<?= $ev['evidence_id'] ?>&case_id=<?= $case_id ?>"
                           class="btn btn-outline-danger"
                           onclick="return confirm('Delete this evidence record?');">
                            <i class="bi bi-trash"></i>
                        </a>
                    </div>
                    <?php endif; ?>
                </div>

                <p class="text-muted small mb-2">
                    <?= $ev['date_collected'] ? date("F j, Y", strtotime($ev['date_collected'])) : '—' ?>
                </p>
                <p class="mb-1"><strong>Type:</strong> <?= $ev['type'] ?></p>
                <p class="mb-1"><strong>Collected by:</strong> <?= $ev['collected_by_name'] ?? 'N/A' ?></p>
                <p class="mb-1"><strong>Status:</strong> <?= $ev['status'] ?></p>
                <?php if ($ev['file_path']): ?>
                <p class="mb-1"><strong>File:</strong> 
                    <a href="<?= htmlspecialchars('/crime_analytics/' . $ev['file_path']) ?>" target="_blank">View/Download</a>
                </p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- VIEW Evidence Modal -->
    <div class="modal fade" id="viewEvidenceModal<?= $ev['evidence_id'] ?>" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Evidence #<?= $ev['evidence_id'] ?></h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <p><strong>Description:</strong> <?= htmlspecialchars($ev['description']) ?></p>
            <p><strong>Type:</strong> <?= $ev['type'] ?></p>
            <p><strong>Date Collected:</strong> <?= $ev['date_collected'] ?: '—' ?></p>
            <p><strong>Collected by:</strong> <?= $ev['collected_by_name'] ?? 'N/A' ?></p>
            <p><strong>Status:</strong> <?= $ev['status'] ?></p>
            <p><strong>Chain of Custody:</strong> <?= nl2br(htmlspecialchars($ev['chain_of_custody'])) ?></p>
            <?php if ($ev['file_path']): ?>
            <p><strong>File:</strong> <a href="<?= htmlspecialchars('/crime_analytics/' . $ev['file_path']) ?>" target="_blank">View/Download</a></p>
            <?php endif; ?>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div>

    <!-- EDIT Evidence Modal -->
    <?php if ($can_edit): ?>
    <div class="modal fade" id="editEvidenceModal<?= $ev['evidence_id'] ?>" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <form action="evidence/edit_evidence.php" method="POST" enctype="multipart/form-data" class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Edit Evidence #<?= $ev['evidence_id'] ?></h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <input type="hidden" name="evidence_id" value="<?= $ev['evidence_id'] ?>">
            <input type="hidden" name="case_id" value="<?= $ev['case_id'] ?>">

            <div class="mb-3">
                <label class="form-label">Description</label>
                <textarea name="description" class="form-control"><?= htmlspecialchars($ev['description']) ?></textarea>
            </div>

            <div class="mb-3">
                <label class="form-label">Type</label>
                <select name="type" class="form-select">
                    <option value="Weapon" <?= $ev['type']=='Weapon'?'selected':'' ?>>Weapon</option>
                    <option value="Document" <?= $ev['type']=='Document'?'selected':'' ?>>Document</option>
                    <option value="Photo" <?= $ev['type']=='Photo'?'selected':'' ?>>Photo</option>
                    <option value="Digital" <?= $ev['type']=='Digital'?'selected':'' ?>>Digital</option>
                    <option value="Other" <?= $ev['type']=='Other'?'selected':'' ?>>Other</option>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Collected by</label>
                <select name="collected_by" class="form-select">
                    <option value="">—</option>
                    <?php foreach($officers as $o): ?>
                    <option value="<?= $o['officer_id'] ?>" <?= $o['officer_id']==$ev['collected_by']?'selected':'' ?>>
                        <?= htmlspecialchars($o['full_name']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Date Collected</label>
                <input type="date" name="date_collected" class="form-control" value="<?= $ev['date_collected'] ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">Status</label>
                <select name="status" class="form-select">
                    <option value="Submitted" <?= $ev['status']=='Submitted'?'selected':'' ?>>Submitted</option>
                    <option value="Analyzed" <?= $ev['status']=='Analyzed'?'selected':'' ?>>Analyzed</option>
                    <option value="Archived" <?= $ev['status']=='Archived'?'selected':'' ?>>Archived</option>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Chain of Custody</label>
                <textarea name="chain_of_custody" class="form-control"><?= htmlspecialchars($ev['chain_of_custody']) ?></textarea>
            </div>

            <div class="mb-3">
                <label class="form-label">Upload File (optional)</label>
                <input type="file" name="evidence_file" class="form-control">
                <?php if($ev['file_path']): ?>
                <small>Current file: <a href="<?= htmlspecialchars('/crime_analytics/' . $ev['file_path']) ?>" target="_blank">View/Download</a></small>
                <?php endif; ?>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary">Save Changes</button>
          </div>
        </form>
      </div>
    </div>
    <?php endif; ?>

<?php endforeach; ?>
</div>
<?php endif; ?>

<!-- ADD Evidence Modal -->
<?php if($can_edit): ?>
<div class="modal fade" id="addEvidenceModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <form action="evidence/add_evidence.php" method="POST" enctype="multipart/form-data" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Add Evidence</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" name="case_id" value="<?= $case_id ?>">

        <div class="mb-3">
            <label class="form-label">Description</label>
            <textarea name="description" class="form-control"></textarea>
        </div>

        <div class="mb-3">
            <label class="form-label">Type</label>
            <select name="type" class="form-select">
                <option value="Weapon">Weapon</option>
                <option value="Document">Document</option>
                <option value="Photo">Photo</option>
                <option value="Digital">Digital</option>
                <option value="Other" selected>Other</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Collected by</label>
            <select name="collected_by" class="form-select">
                <option value="">—</option>
                <?php foreach($officers as $o): ?>
                <option value="<?= $o['officer_id'] ?>"><?= htmlspecialchars($o['full_name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Date Collected</label>
            <input type="date" name="date_collected" class="form-control">
        </div>

        <div class="mb-3">
            <label class="form-label">Status</label>
            <select name="status" class="form-select">
                <option value="Submitted" selected>Submitted</option>
                <option value="Analyzed">Analyzed</option>
                <option value="Archived">Archived</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Chain of Custody</label>
            <textarea name="chain_of_custody" class="form-control"></textarea>
        </div>

        <div class="mb-3">
            <label class="form-label">Upload File (optional)</label>
            <input type="file" name="evidence_file" class="form-control">
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-primary">Add Evidence</button>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>
