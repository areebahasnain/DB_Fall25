<?php
// /cases/documents.php
require_once "../config/database.php";
require_once "../includes/functions.php";
require_once "../includes/auth.php";

// Fetch documents for this case
$docStmt = $pdo->prepare("
    SELECT d.*, u.username AS uploaded_by_name
    FROM case_documents d
    LEFT JOIN users u ON d.uploaded_by = u.user_id
    WHERE d.case_id = ?
    ORDER BY d.uploaded_at DESC
");
$docStmt->execute([$case_id]);
$documents = $docStmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="tab-pane fade <?= $tab=='documents' ? 'show active' : '' ?>" id="documents" role="tabpanel" aria-labelledby="documents-tab">

<?php if (!empty($_SESSION['success'])): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?= $_SESSION['success'] ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php unset($_SESSION['success']); endif; ?>

<?php if (!empty($_SESSION['error'])): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <?= $_SESSION['error'] ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php unset($_SESSION['error']); endif; ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">Documents</h5>
    <?php if ($can_edit): ?>
    <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addDocumentModal">
        <i class="bi bi-plus-circle me-1"></i> Add Document
    </button>
    <?php endif; ?>
</div>

<?php if (empty($documents)): ?>
    <div class="alert alert-info">No documents uploaded for this case.</div>
<?php else: ?>
<div class="row g-3">
<?php foreach ($documents as $doc): ?>
    <div class="col-md-6 mb-3">
        <div class="card shadow-sm border-0 rounded-4">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <h6 class="fw-bold mb-1"><?= htmlspecialchars($doc['file_name']) ?></h6>
                    <?php if ($can_edit): ?>
                    <div class="btn-group btn-group-sm">
                        <a href="cases/delete_document.php?document_id=<?= $doc['document_id'] ?>&case_id=<?= $case_id ?>"
                           class="btn btn-outline-danger"
                           onclick="return confirm('Delete this document?');">
                            <i class="bi bi-trash"></i>
                        </a>
                    </div>
                    <?php endif; ?>
                </div>

                <p class="text-muted small mb-2">
                    Uploaded by <?= htmlspecialchars($doc['uploaded_by_name'] ?? 'N/A') ?> on <?= date("F j, Y", strtotime($doc['uploaded_at'])) ?>
                </p>

                <a href="<?= htmlspecialchars($doc['file_path']) ?>" target="_blank" class="btn btn-sm btn-outline-secondary">
                    <i class="bi bi-eye me-1"></i> View / Download
                </a>
            </div>
        </div>
    </div>
<?php endforeach; ?>
</div>
<?php endif; ?>

<!-- ADD Document Modal -->
<?php if ($can_edit): ?>
<div class="modal fade" id="addDocumentModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <form action="cases/add_document.php" method="POST" enctype="multipart/form-data" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Add Document</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" name="case_id" value="<?= $case_id ?>">

        <div class="mb-3">
            <label class="form-label">Document File</label>
            <input type="file" name="document_file" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">File Name (Optional)</label>
            <input type="text" name="file_name" class="form-control">
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-primary" type="submit">Upload Document</button>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

