<?php
// Prevent direct access
if (!isset($case) || !isset($case_id)) {
    die("Invalid access.");
}

// Helper function to fetch counts (optional: cache all in one query for performance)
function getCount($pdo, $query, $params) {
    $st = $pdo->prepare($query);
    $st->execute($params);
    return $st->fetchColumn();
}
?>

<div class="row g-4">

    <!-- LEFT SIDE: Case Details Card -->
    <div class="col-lg-6">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">Case Details</h5>
            </div>
            <div class="card-body">

                <div class="mb-2">
                    <strong>Case ID:</strong><br>
                    <span class="text-muted"><?= $case_id; ?></span>
                </div>

                <div class="mb-2">
                    <strong>Case Title:</strong><br>
                    <span class="text-muted"><?= htmlspecialchars($case['title']); ?></span>
                </div>

                <div class="mb-2">
                    <strong>Status:</strong><br>
                    <span class="badge bg-info" data-bs-toggle="tooltip" title="Current case status"><?= htmlspecialchars($case['status']); ?></span>
                </div>

                <div class="mb-2">
                    <strong>Priority:</strong><br>
                    <span class="badge 
                        <?= $case['priority']=='High' ? 'bg-danger' : ($case['priority']=='Medium' ? 'bg-warning text-dark' : 'bg-secondary'); ?>"
                        data-bs-toggle="tooltip" title="Case priority level">
                        <?= htmlspecialchars($case['priority']); ?>
                    </span>
                </div>

                <div class="mb-2">
                    <strong>Assigned Officer:</strong><br>
                    <?php if(!empty($case['officer_name'])): ?>
                        <a href="officers/view_officer.php?id=<?= $case['assigned_officer_id'] ?>" class="text-decoration-none">
                            <?= htmlspecialchars($case['officer_name']); ?>
                        </a>
                    <?php else: ?>
                        <span class="text-muted">Unassigned</span>
                    <?php endif; ?>
                </div>

                <div class="mb-2">
                    <strong>Department:</strong><br>
                    <?= $case['dept_name'] ?: "<span class='text-muted'>—</span>"; ?>
                </div>

                <div class="mb-2">
                    <strong>Created On:</strong><br>
                    <?= date("d M Y", strtotime($case['case_date'])); ?>
                </div>

                <div>
                    <strong>Last Updated:</strong><br>
                    <?= date("d M Y, h:i A", strtotime($case['updated_at'])); ?>
                </div>

            </div>
        </div>
    </div>

    <!-- RIGHT SIDE: Narrative / Description -->
    <div class="col-lg-6">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-dark text-white">
                <h5 class="mb-0">Case Description</h5>
            </div>
            <div class="card-body" style="min-height: 260px; max-height: 400px; overflow-y: auto;">

                <?php if (!empty($case['description'])): ?>
                    <p style="white-space: pre-line;"><?= nl2br(htmlspecialchars($case['description'])); ?></p>
                <?php else: ?>
                    <div class="text-muted fst-italic">No description provided for this case.</div>
                <?php endif; ?>

            </div>
        </div>
    </div>

</div>

<!-- QUICK STATS: Clickable cards -->
<div class="row mt-4 g-4">

    <?php
    $stats = [
    ['title' => 'Victims', 'icon' => 'bi-person-fill', 
     'count' => getCount($pdo, "SELECT COUNT(*) FROM victim_cases WHERE case_id = ?", [$case_id]), 
     'tab' => 'victims'],
     
    ['title' => 'Suspects', 'icon' => 'bi-person-badge-fill', 
     'count' => getCount($pdo, "SELECT COUNT(*) FROM case_criminals WHERE case_id = ?", [$case_id]), 
     'tab' => 'suspects'],
     
    ['title' => 'Evidence Items', 'icon' => 'bi-folder-fill', 
     'count' => getCount($pdo, "SELECT COUNT(*) FROM evidence WHERE case_id = ?", [$case_id]), 
     'tab' => 'evidence'],
     
    ['title' => 'Timeline Events', 'icon' => 'bi-clock-fill', 
     'count' => getCount($pdo, "SELECT COUNT(*) FROM case_timeline WHERE case_id = ?", [$case_id]), 
     'tab' => 'timeline'],
];

    ?>

    <?php foreach($stats as $stat): ?>
    <div class="col-md-3">
        <div class="card text-center shadow-sm border-0 h-100">
            <div class="card-body">
                <i class="bi <?= $stat['icon'] ?> fs-2 mb-2 text-secondary"></i>
                <h6 class="text-muted mb-1"><?= $stat['title'] ?></h6>
                <h3 class="fw-bold">
                    <a href="#<?= $stat['tab'] ?>" data-bs-toggle="tab" class="text-decoration-none">
                        <?= $stat['count']; ?>
                    </a>
                </h3>
            </div>
        </div>
    </div>
    <?php endforeach; ?>

</div>

<!-- Initialize Bootstrap tooltips -->
<script>
document.addEventListener('DOMContentLoaded', function () {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    })
});
</script>
