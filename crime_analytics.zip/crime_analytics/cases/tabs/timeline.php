<?php
// tabs/timeline.php
if (!isset($case_id)) return;

$stmt = $pdo->prepare("
    SELECT t.*, u.full_name AS user_name
    FROM case_timeline t
    LEFT JOIN users u ON t.created_by = u.user_id
    WHERE t.case_id = ?
    ORDER BY t.event_date DESC
");
$stmt->execute([$case_id]);
$events = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="section-card">
    <h5>Timeline</h5>
    <?php if (!$events): ?>
        <div class="alert alert-secondary">No events recorded for this case yet.</div>
    <?php else: ?>
        <ul class="list-group list-group-flush">
            <?php foreach ($events as $e): ?>
                <li class="list-group-item">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <strong><?= htmlspecialchars($e['title']) ?></strong>
                            <?php if ($e['description']): ?>
                                <div class="small text-muted"><?= nl2br(htmlspecialchars($e['description'])) ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="text-end small text-muted">
                            <?= date('Y-m-d H:i', strtotime($e['event_date'])) ?>
                            <?= $e['user_name'] ? "by " . htmlspecialchars($e['user_name']) : '' ?>
                        </div>
                    </div>
                    <small class="badge bg-secondary"><?= htmlspecialchars($e['event_type']) ?></small>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
</div>
