<?php
// /cases/evidence/delete_evidence.php
define('BASE_PATH', realpath(__DIR__ . '/../../') . '/');
define('UPLOADS_WEB', '/crime_analytics/uploads/evidence/'); // Web path
define('UPLOADS_DIR', BASE_PATH . 'uploads/evidence/'); // Server path

require_once BASE_PATH . "config/database.php";
require_once BASE_PATH . "includes/functions.php";
require_once BASE_PATH . "includes/auth.php";

// Check permissions
$can_edit = isset($_SESSION['role']) && in_array($_SESSION['role'], ['Admin', 'Officer']);
$evidence_id = $_GET['evidence_id'] ?? null;
$case_id = $_GET['case_id'] ?? null;

if (!$can_edit || !$evidence_id || !$case_id) {
    die("Access denied.");
}

// Fetch evidence to get file path
$stmt = $pdo->prepare("SELECT file_path, description FROM evidence WHERE evidence_id=?");
$stmt->execute([$evidence_id]);
$ev = $stmt->fetch(PDO::FETCH_ASSOC);

if ($ev) {
    // Delete file if exists
    if ($ev['file_path'] && file_exists(BASE_PATH . ltrim($ev['file_path'], '/'))) {
        unlink(BASE_PATH . ltrim($ev['file_path'], '/'));
    }

    // Delete record
    $stmt = $pdo->prepare("DELETE FROM evidence WHERE evidence_id=?");
    $stmt->execute([$evidence_id]);
    
    require_once BASE_PATH . "includes/functions_timeline.php";
    log_case_event($case_id, "Evidence deleted", "'{$ev['description']}' was removed from evidence.", 'Evidence', $_SESSION['user_id']);

    $_SESSION['success'] = "Evidence deleted successfully.";
}

redirect("/crime_analytics/cases/view_case.php?id={$case_id}&tab=evidence");
