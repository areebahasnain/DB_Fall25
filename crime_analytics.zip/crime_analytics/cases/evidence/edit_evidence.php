<?php
// /cases/evidence/edit_evidence.php
define('BASE_PATH', realpath(__DIR__ . '/../../') . '/');
define('UPLOADS_WEB', '/crime_analytics/uploads/evidence/'); // Web-accessible path
define('UPLOADS_DIR', BASE_PATH . 'uploads/evidence/'); // Server path

require_once BASE_PATH . "config/database.php";
require_once BASE_PATH . "includes/functions.php";
require_once BASE_PATH . "includes/auth.php";

// Define permissions based on user role
$can_edit = isset($_SESSION['role']) && in_array($_SESSION['role'], ['Admin', 'Officer']);
if (!$can_edit) die("Access denied.");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $evidence_id = $_POST['evidence_id'] ?? null;
    $case_id = $_POST['case_id'] ?? null;
    $description = $_POST['description'] ?? '';
    $type = $_POST['type'] ?? 'Other';
    $collected_by = $_POST['collected_by'] ?: null;
    $date_collected = $_POST['date_collected'] ?: null;
    $status = $_POST['status'] ?? 'Submitted';
    $chain_of_custody = $_POST['chain_of_custody'] ?? '';

    if (!$evidence_id || !is_numeric($evidence_id) || !$case_id) {
        redirect("/crime_analytics/cases/view_case.php?id={$case_id}&tab=evidence");
    }

    // Fetch existing record
    $stmt = $pdo->prepare("SELECT * FROM evidence WHERE evidence_id = ?");
    $stmt->execute([$evidence_id]);
    $ev = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$ev) redirect("/crime_analytics/cases/view_case.php?id={$case_id}&tab=evidence");

    // File upload handling
    $file_path = $ev['file_path']; // keep existing by default
    if (!empty($_FILES['evidence_file']['name'])) {
        if (!is_dir(UPLOADS_DIR)) mkdir(UPLOADS_DIR, 0777, true);

        $file_name = basename($_FILES['evidence_file']['name']);
        $safe_name = time() . "_" . preg_replace("/[^a-zA-Z0-9_\.-]/", "_", $file_name);
        $target_file = UPLOADS_DIR . $safe_name;

        if (move_uploaded_file($_FILES['evidence_file']['tmp_name'], $target_file)) {
            // delete old file if exists
            if ($file_path && file_exists(BASE_PATH . ltrim($file_path, '/'))) unlink(BASE_PATH . ltrim($file_path, '/'));
            $file_path = UPLOADS_WEB . $safe_name; // Store web path
        }
    }

    // Update record
    $stmt = $pdo->prepare("
        UPDATE evidence SET
        description=:description, type=:type, collected_by=:collected_by,
        date_collected=:date_collected, status=:status, chain_of_custody=:chain_of_custody,
        file_path=:file_path
        WHERE evidence_id=:evidence_id
    ");
    $stmt->execute([
        ':description' => $description,
        ':type' => $type,
        ':collected_by' => $collected_by,
        ':date_collected' => $date_collected,
        ':status' => $status,
        ':chain_of_custody' => $chain_of_custody,
        ':file_path' => $file_path,
        ':evidence_id' => $evidence_id
    ]);

    require_once BASE_PATH . "includes/functions_timeline.php";
    log_case_event($case_id, "Evidence updated", "Evidence '$description' details edited.", 'Evidence', $_SESSION['user_id']);

    $_SESSION['success'] = "Evidence updated successfully.";
    redirect("/crime_analytics/cases/view_case.php?id={$case_id}&tab=evidence");
}
