<?php
// /cases/evidence/add_evidence.php
define('BASE_PATH', realpath(__DIR__ . '/../../') . '/');
define('UPLOADS_WEB', '/crime_analytics/uploads/evidence/'); // Absolute web path
define('UPLOADS_DIR', BASE_PATH . 'uploads/evidence/'); // Server path

require_once BASE_PATH . "config/database.php";
require_once BASE_PATH . "includes/functions.php";
require_once BASE_PATH . "includes/auth.php";

// Define permissions based on user role
$can_edit = isset($_SESSION['role']) && in_array($_SESSION['role'], ['Admin', 'Officer']);
if (!$can_edit) {
    die("Access denied.");
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $case_id = $_POST['case_id'] ?? null;
    $description = $_POST['description'] ?? '';
    $type = $_POST['type'] ?? 'Other';
    $collected_by = $_POST['collected_by'] ?: null;
    $date_collected = $_POST['date_collected'] ?: null;
    $status = $_POST['status'] ?? 'Submitted';
    $chain_of_custody = $_POST['chain_of_custody'] ?? '';

    $errors = [];

    if (!$case_id || !is_numeric($case_id)) $errors[] = "Invalid case ID.";

    // File upload handling
    $file_path = null;
    if (!empty($_FILES['evidence_file']['name'])) {
        if (!is_dir(UPLOADS_DIR)) mkdir(UPLOADS_DIR, 0777, true);

        $file_name = basename($_FILES['evidence_file']['name']);
        $safe_name = time() . "_" . preg_replace("/[^a-zA-Z0-9_\.-]/", "_", $file_name);
        $target_file = UPLOADS_DIR . $safe_name;

        if (move_uploaded_file($_FILES['evidence_file']['tmp_name'], $target_file)) {
            $file_path = UPLOADS_WEB . $safe_name; // Store web path for links
        } else {
            $errors[] = "Failed to upload file.";
        }
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare("
            INSERT INTO evidence 
            (case_id, description, type, collected_by, date_collected, status, chain_of_custody, file_path)
            VALUES (:case_id, :description, :type, :collected_by, :date_collected, :status, :chain_of_custody, :file_path)
        ");
        $stmt->execute([
            ':case_id' => $case_id,
            ':description' => $description,
            ':type' => $type,
            ':collected_by' => $collected_by,
            ':date_collected' => $date_collected,
            ':status' => $status,
            ':chain_of_custody' => $chain_of_custody,
            ':file_path' => $file_path
        ]);

        // Log timeline event
        require_once BASE_PATH . "includes/functions_timeline.php";
        log_case_event($case_id, "Evidence uploaded", "Evidence '$description' uploaded.", 'Evidence', $_SESSION['user_id']);

        $_SESSION['success'] = "Evidence added successfully.";

        // Redirect using absolute path
        redirect("/crime_analytics/cases/view_case.php?id={$case_id}&tab=evidence");
    }

    if (!empty($errors)) {
        $_SESSION['error'] = implode("<br>", $errors);
        redirect("/crime_analytics/cases/view_case.php?id={$case_id}&tab=evidence");
    }
}
