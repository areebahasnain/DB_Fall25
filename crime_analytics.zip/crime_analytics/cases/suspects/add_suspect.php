<?php
require_once "../../config/database.php";
require_once "../../includes/auth.php";
require_once "../../includes/functions.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/CRIME_ANALYTICS/cases/view_case.php?error=Invalid request');
}

$case_id        = (int)$_POST['case_id'];
$name           = trim($_POST['name']);
$criminal_id    = !empty($_POST['criminal_id']) ? (int)$_POST['criminal_id'] : null;
$contact_number = trim($_POST['contact_number']);
$email          = trim($_POST['email']);
$address        = trim($_POST['address']);
$notes          = trim($_POST['notes']);
$added_by       = $_SESSION['user_id'];

// No image column used anymore
$imagePath = null;

$stmt = $pdo->prepare("
    INSERT INTO suspects (case_id, name, criminal_id, contact_number, email, address, notes, added_by)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
");

$stmt->execute([
    $case_id,
    $name,
    $criminal_id,
    $contact_number,
    $email,
    $address,
    $notes,
    $added_by
]);

require_once "../../includes/functions_timeline.php";
log_case_event($case_id, "Suspect added", "Suspect $name was added to the case.", 'Suspect', $_SESSION['user_id']);

redirect("/CRIME_ANALYTICS/cases/view_case.php?case_id=$case_id&success=Suspect added");
