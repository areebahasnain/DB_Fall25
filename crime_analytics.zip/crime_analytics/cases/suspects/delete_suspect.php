<?php
require_once "../../config/database.php";
require_once "../../includes/auth.php";
require_once "../../includes/functions.php";

if (!isset($_GET['suspect_id']) || !isset($_GET['case_id'])) {
    redirect('../view_case.php?error=Invalid request');
}

$suspect_id = (int)$_GET['suspect_id'];
$case_id    = (int)$_GET['case_id'];

// Fetch suspect name for timeline log
$stmt = $pdo->prepare("SELECT name FROM suspects WHERE suspect_id = ?");
$stmt->execute([$suspect_id]);
$suspect = $stmt->fetch(PDO::FETCH_ASSOC);

$suspect_name = $suspect ? $suspect['name'] : "Unknown";

// Delete record
$delete = $pdo->prepare("DELETE FROM suspects WHERE suspect_id = ?");
$delete->execute([$suspect_id]);

require_once "../../includes/functions_timeline.php";
log_case_event(
    $case_id,
    "Suspect deleted",
    "Suspect $suspect_name was removed from the suspect list.",
    'Suspect',
    $_SESSION['user_id']
);

// Redirect
redirect("../view_case.php?case_id=$case_id&success=Suspect deleted");
