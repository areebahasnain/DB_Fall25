<?php
require_once "../../config/database.php";
require_once "../../includes/auth.php";
require_once "../../includes/functions.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/CRIME_ANALYTICS/cases/view_case.php?error=Invalid request');
}

$suspect_id = (int)$_POST['suspect_id'];
$case_id    = (int)$_POST['case_id'];

$name           = trim($_POST['name']);
$criminal_id    = !empty($_POST['criminal_id']) ? (int)$_POST['criminal_id'] : null;
$contact_number = trim($_POST['contact_number']);
$email          = trim($_POST['email']);
$address        = trim($_POST['address']);
$notes          = trim($_POST['notes']);

// Update suspect (NO IMAGE COLUMN)
$stmt = $pdo->prepare("
    UPDATE suspects
    SET name = ?, criminal_id = ?, contact_number = ?, email = ?, address = ?, notes = ?
    WHERE suspect_id = ?
");

$stmt->execute([
    $name,
    $criminal_id,
    $contact_number,
    $email,
    $address,
    $notes,
    $suspect_id
]);

require_once "../../includes/functions_timeline.php";
log_case_event($case_id, "Suspect updated", "Suspect $name details were edited.", 'Suspect', $_SESSION['user_id']);

redirect("/CRIME_ANALYTICS/cases/view_case.php?case_id=$case_id&success=Suspect updated");
