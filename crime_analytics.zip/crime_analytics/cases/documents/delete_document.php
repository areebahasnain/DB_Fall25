<?php
// /cases/delete_document.php
require_once "../config/database.php";
require_once "../includes/functions.php";
require_once "../includes/auth.php";

if (!$can_edit) die("Access denied.");

$document_id = $_GET['document_id'] ?? null;
$case_id = $_GET['case_id'] ?? null;

if (!$document_id || !$case_id) redirect("../cases/list_cases.php");

// Fetch file path to delete the file
$stmt = $pdo->prepare("SELECT file_path FROM case_documents WHERE document_id = ?");
$stmt->execute([$document_id]);
$doc = $stmt->fetch(PDO::FETCH_ASSOC);

if ($doc) {
    if (file_exists($doc['file_path'])) unlink($doc['file_path']);

    $stmt = $pdo->prepare("DELETE FROM case_documents WHERE document_id = ?");
    $stmt->execute([$document_id]);

    $_SESSION['success'] = "Document deleted successfully.";
}

require_once "../../includes/functions_timeline.php";
log_case_event($case_id, "Document deleted", "Document '$filename' deleted.", 'Document', $_SESSION['user_id']);

redirect("../cases/view_case.php?id={$case_id}&tab=documents");
