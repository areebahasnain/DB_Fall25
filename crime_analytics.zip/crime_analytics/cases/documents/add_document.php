<?php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
require_once "../../includes/auth.php";

require_role(['Admin', 'Officer']);

$case_id = $_POST['case_id'];

if (!isset($_FILES['document'])) {
    die("No file uploaded.");
}

$file = $_FILES['document'];
$uploadDir = "../../<?php
// /cases/add_document.php
require_once "../config/database.php";
require_once "../includes/functions.php";
require_once "../includes/auth.php";

if (!$can_edit) die("Access denied.");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $case_id = $_POST['case_id'] ?? null;
    $file_name = $_POST['file_name'] ?? null;
    $uploaded_by = $_SESSION['user_id'] ?? null;

    if (!isset($_FILES['document_file']) || $_FILES['document_file']['error'] !== UPLOAD_ERR_OK) {
        $_SESSION['error'] = "Please select a valid file to upload.";
        redirect("../cases/view_case.php?id={$case_id}&tab=documents");
    }

    $uploadDir = "../uploads/case_documents/";
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

    $originalName = $_FILES['document_file']['name'];
    $ext = pathinfo($originalName, PATHINFO_EXTENSION);
    $safeName = uniqid() . "." . $ext;
    $destination = $uploadDir . $safeName;

    if (move_uploaded_file($_FILES['document_file']['tmp_name'], $destination)) {

        if (!$file_name) $file_name = $originalName;

        $stmt = $pdo->prepare("
            INSERT INTO case_documents (case_id, file_name, file_path, uploaded_by)
            VALUES (:case_id, :file_name, :file_path, :uploaded_by)
        ");
        $stmt->execute([
            ':case_id' => $case_id,
            ':file_name' => $file_name,
            ':file_path' => $destination,
            ':uploaded_by' => $uploaded_by
        ]);

        $_SESSION['success'] = "Document uploaded successfully.";
        redirect("../cases/view_case.php?id={$case_id}&tab=documents");

    } else {
        $_SESSION['error'] = "Failed to upload the file.";
        redirect("../cases/view_case.php?id={$case_id}&tab=documents");
    }
}
uploads/";

$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
$allowed = ['pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx', 'xls', 'xlsx'];

if (!in_array($ext, $allowed)) {
    die("Invalid file type.");
}

$storedName = uniqid() . "." . $ext;
$target = $uploadDir . $storedName;

if (!move_uploaded_file($file['tmp_name'], $target)) {
    die("Upload failed.");
}

$stmt = $pdo->prepare("
    INSERT INTO case_documents (case_id, file_name, file_path, file_type, uploaded_by)
    VALUES (?, ?, ?, ?, ?)
");

$stmt->execute([
    $case_id,
    $file['name'],
    $storedName,
    $ext,
    $_SESSION['user_id']
]);

require_once "../../includes/functions_timeline.php";
log_case_event($case_id, "Document uploaded", "Document '$filename' uploaded.", 'Document', $_SESSION['user_id']);

redirect("../view_case.php?id=$case_id&tab=documents");
