<?php
require "../../config/database.php";
require "../../includes/auth.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') exit;

$case_id = $_POST['case_id'];
$court_name = $_POST['court_name'];
$trial_date = $_POST['trial_date'] ?: null;
$verdict = $_POST['verdict'];
$legal_representative = $_POST['legal_representative'];
$appeal_status = $_POST['appeal_status'];
$sentence_details = $_POST['sentence_details'];

$stmt = $pdo->prepare("
    INSERT INTO trials (case_id, court_name, trial_date, verdict, legal_representative, appeal_status, sentence_details)
    VALUES (?, ?, ?, ?, ?, ?, ?)
");
$stmt->execute([
    $case_id, $court_name, $trial_date, $verdict,
    $legal_representative, $appeal_status, $sentence_details
]);

require_once "../../includes/functions_timeline.php";
log_case_event($case_id, "Trial scheduled", "Trial at '$court_name' scheduled.", 'Trial', $_SESSION['user_id']);


header("Location: ../view_case.php?case_id=$case_id&tab=trials");
exit;
