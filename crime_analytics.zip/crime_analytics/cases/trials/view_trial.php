<?php
require_once "../config/database.php";
require_once "../includes/functions.php";
require_once "../includes/auth.php"; // Check login

if (!isset($_GET['trial_id'])) {
    redirect("trials.php");
}

$trial_id = (int)$_GET['trial_id'];

$stmt = $pdo->prepare("SELECT t.*, c.title AS case_title 
                       FROM trials t
                       LEFT JOIN cases c ON t.case_id = c.case_id
                       WHERE t.trial_id = ?");
$stmt->execute([$trial_id]);
$trial = $stmt->fetch();

if (!$trial) {
    die("Trial not found.");
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>View Trial</title>
    <link rel="stylesheet" href="../assets/bootstrap.min.css">
</head>
<body class="p-4">

<div class="container">
    <h2 class="mb-4">Trial Details</h2>

    <div class="card shadow">
        <div class="card-body">

            <h4>Case: <?= htmlspecialchars($trial['case_title']) ?></h4>
            <hr>

            <p><strong>Court Name:</strong> <?= htmlspecialchars($trial['court_name']) ?></p>
            <p><strong>Trial Date:</strong> <?= htmlspecialchars($trial['trial_date']) ?></p>
            <p><strong>Verdict:</strong> 
                <span class="badge bg-primary"><?= htmlspecialchars($trial['verdict']) ?></span>
            </p>

            <p><strong>Legal Representative:</strong> <?= htmlspecialchars($trial['legal_representative']) ?></p>

            <p><strong>Appeal Status:</strong> 
                <span class="badge bg-warning"><?= htmlspecialchars($trial['appeal_status']) ?></span>
            </p>

            <p><strong>Sentence Details:</strong><br>
                <?= nl2br(htmlspecialchars($trial['sentence_details'])) ?>
            </p>

            <a href="trials.php" class="btn btn-secondary mt-3">Back</a>
        </div>
    </div>
</div>

</body>
</html>
