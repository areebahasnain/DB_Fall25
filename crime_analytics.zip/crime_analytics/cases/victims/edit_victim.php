<?php
// victims/edit_victim.php
session_start();
require_once "../../config/database.php";

$role = $_SESSION['role'] ?? 'Analyst';
$isAdmin = $role === 'Admin';
$isOfficer = $role === 'Officer';

if (!($isAdmin || $isOfficer)) {
    die("Access denied");
}

// Get POST data
$case_id = $_POST['case_id'] ?? null;
$victim_id = $_POST['victim_id'] ?? null;
$full_name = trim($_POST['full_name'] ?? '');
$dob = $_POST['dob'] ?? null;
$gender = $_POST['gender'] ?? null;
$address = $_POST['address'] ?? null;
$contact = $_POST['contact'] ?? null;
$role_in_case = $_POST['role_in_case'] ?? 'Victim';

if (!$case_id || !$victim_id || !$full_name) {
    die("Missing required fields.");
}

try {
    $pdo->beginTransaction();

    // Update victim info
    $stmt = $pdo->prepare("
        UPDATE victims
        SET full_name = ?, dob = ?, gender = ?, address = ?, contact = ?
        WHERE victim_id = ?
    ");
    $stmt->execute([$full_name, $dob, $gender, $address, $contact, $victim_id]);

    // Update role in this case
    $stmt2 = $pdo->prepare("
        UPDATE victim_cases
        SET role_in_case = ?
        WHERE victim_id = ? AND case_id = ?
    ");
    $stmt2->execute([$role_in_case, $victim_id, $case_id]);

    require_once "../../includes/functions_timeline.php";
    log_case_event($case_id, "Victim updated", "Victim $full_name details were edited.", 'Victim', $_SESSION['user_id']);

    $pdo->commit();
    header("Location: ../view_case.php?case_id=$case_id");
    exit;

} catch (Exception $e) {
    $pdo->rollBack();
    die("Error editing victim: " . $e->getMessage());
}
