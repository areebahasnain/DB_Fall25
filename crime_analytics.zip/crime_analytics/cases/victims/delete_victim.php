<?php
require_once "../../config/database.php";
require_once "../../includes/auth.php";
require_once "../../includes/functions.php";

// Only Admin should be allowed to delete (optional: remove if not needed)
if ($_SESSION['role'] !== 'Admin') {
    redirect("/CRIME_ANALYTICS/dashboard.php?error=Access denied");
}

if (!isset($_GET['victim_id'], $_GET['case_id'])) {
    redirect("/CRIME_ANALYTICS/cases/view_case.php?error=Invalid request");
}

$victim_id = (int)$_GET['victim_id'];
$case_id   = (int)$_GET['case_id'];

// Fetch victim record (for logging)
$stmt = $pdo->prepare("SELECT full_name FROM victims WHERE victim_id = ?");
$stmt->execute([$victim_id]);
$victim = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$victim) {
    redirect("/CRIME_ANALYTICS/cases/view_case.php?case_id=$case_id&error=Victim not found");
}

// Delete victim from database
$stmt = $pdo->prepare("DELETE FROM victims WHERE victim_id = ?");
$stmt->execute([$victim_id]);

// Log timeline event
require_once "../../includes/functions_timeline.php";
log_case_event(
    $case_id,
    "Victim deleted",
    "Victim {$victim['full_name']} was removed from the case.",
    'Victim',
    $_SESSION['user_id']
);

// Redirect back
redirect("/CRIME_ANALYTICS/cases/view_case.php?case_id=$case_id&success=Victim deleted");
