<?php
// victims/add_victim.php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . "/CRIME_ANALYTICS/config/database.php";

$role = $_SESSION['role'] ?? 'Analyst';
$isAdmin = $role === 'Admin';
$isOfficer = $role === 'Officer';

if (!($isAdmin || $isOfficer)) {
    die("Access denied");
}

// Get POST data
$case_id = $_POST['case_id'] ?? null;
$full_name = trim($_POST['full_name'] ?? '');
$dob = $_POST['dob'] ?? null;
$gender = $_POST['gender'] ?? null;
$address = $_POST['address'] ?? null;
$contact = $_POST['contact'] ?? null;
$role_in_case = $_POST['role_in_case'] ?? 'Victim';

if (!$case_id || !$full_name) {
    die("Case ID and Full Name are required.");
}

try {
    $pdo->beginTransaction();

    // Insert victim
    $stmt = $pdo->prepare("
        INSERT INTO victims (full_name, dob, gender, address, contact)
        VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->execute([$full_name, $dob, $gender, $address, $contact]);
    $victim_id = $pdo->lastInsertId();

    // Link to case
    $stmt2 = $pdo->prepare("
        INSERT INTO victim_cases (victim_id, case_id, role_in_case)
        VALUES (?, ?, ?)
    ");
    $stmt2->execute([$victim_id, $case_id, $role_in_case]);
    
    require_once $_SERVER['DOCUMENT_ROOT'] . "/CRIME_ANALYTICS/includes/functions_timeline.php";
    log_case_event($case_id, "Victim added", "Victim $full_name was added to the case.", 'Victim', $_SESSION['user_id']);

    $pdo->commit();
    
    // ✅ Absolute redirect
    header("Location: /CRIME_ANALYTICS/cases/view_case.php?case_id=$case_id");
    exit;

} catch (Exception $e) {
    $pdo->rollBack();
    die("Error adding victim: " . $e->getMessage());
}
