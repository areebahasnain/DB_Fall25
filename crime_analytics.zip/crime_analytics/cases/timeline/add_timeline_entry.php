<?php
// /timeline/add_timeline_entry.php
require_once "../config/database.php";
require_once "../includes/functions.php";
require_once "../includes/auth.php";

$role = $_SESSION['role'] ?? 'Analyst';
$user_id = $_SESSION['user_id'] ?? null;
$can_edit = ($role === 'Admin' || $role === 'Officer');

if (!$can_edit) {
    die("Access denied.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $case_id = $_POST['case_id'] ?? null;
    $title = trim($_POST['title'] ?? '');
    $event_date = $_POST['event_date'] ?? null;
    $description = trim($_POST['description'] ?? '');

    $errors = [];
    if (!$case_id || !is_numeric($case_id)) $errors[] = "Invalid case.";
    if (!$title) $errors[] = "Title is required.";
    if (!$event_date) $errors[] = "Event date is required.";

    if (empty($errors)) {
        $stmt = $pdo->prepare("
            INSERT INTO case_timeline (case_id, title, event_date, description, created_by)
            VALUES (:case_id, :title, :event_date, :description, :created_by)
        ");
        $stmt->execute([
            ':case_id' => $case_id,
            ':title' => $title,
            ':event_date' => $event_date,
            ':description' => $description,
            ':created_by' => $user_id
        ]);

        $_SESSION['success'] = "Timeline entry added successfully.";
        redirect("../cases/view_case.php?id={$case_id}&tab=timeline");
    } else {
        $_SESSION['errors'] = $errors;
        redirect("../cases/view_case.php?id={$case_id}&tab=timeline");
    }
}
