<?php
// /cases/list_cases.php
require_once "../config/database.php";
require_once "../includes/functions.php";
require_once "../includes/auth.php";

$role = $_SESSION['role'] ?? 'Analyst';
$user_id = $_SESSION['user_id'] ?? null;

// Handle search
$search = trim($_GET['search'] ?? '');
$params = [];
$where = '';

if ($search) {
    $where = " WHERE c.title LIKE ? OR c.location LIKE ? OR c.status LIKE ? OR d.name LIKE ?";
    $params = ["%$search%", "%$search%", "%$search%", "%$search%"];
}

// Fetch cases
try {
    if ($role === 'Admin') {
        $sql = "
            SELECT c.*, 
                   u.full_name AS officer_name,
                   d.name AS dept_name
            FROM cases c
            LEFT JOIN officers o ON c.assigned_officer_id = o.officer_id
            LEFT JOIN users u ON o.user_id = u.user_id
            LEFT JOIN departments d ON c.department_id = d.department_id
            $where
            ORDER BY c.case_date DESC
        ";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
    } elseif ($role === 'Officer') {
        // Get officer_id for current user
        $officerStmt = $pdo->prepare("SELECT officer_id FROM officers WHERE user_id = ?");
        $officerStmt->execute([$user_id]);
        $officer = $officerStmt->fetch();
        $officer_id = $officer['officer_id'] ?? 0;

        $sql = "
            SELECT c.*, 
                   u.full_name AS officer_name,
                   d.name AS dept_name
            FROM cases c
            LEFT JOIN officers o ON c.assigned_officer_id = o.officer_id
            LEFT JOIN users u ON o.user_id = u.user_id
            LEFT JOIN departments d ON c.department_id = d.department_id
            WHERE c.assigned_officer_id = ?
        ";
        if ($search) {
            $sql .= " AND (c.title LIKE ? OR c.location LIKE ? OR c.status LIKE ? OR d.name LIKE ?)";
            $params = array_merge([$officer_id], $params);
        } else {
            $params = [$officer_id];
        }
        $sql .= " ORDER BY c.case_date DESC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
    } else {
        // Analyst
        $sql = "
            SELECT c.*, 
                   u.full_name AS officer_name,
                   d.name AS dept_name
            FROM cases c
            LEFT JOIN officers o ON c.assigned_officer_id = o.officer_id
            LEFT JOIN users u ON o.user_id = u.user_id
            LEFT JOIN departments d ON c.department_id = d.department_id
            $where
            ORDER BY c.case_date DESC
        ";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
    }

    $cases = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}

include "../includes/header.php";
?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4>Cases</h4>
        <?php if ($role === 'Admin' || $role === 'Officer'): ?>
            <a href="add_case.php" class="btn btn-primary">Add Case</a>
        <?php endif; ?>
    </div>

    <!-- Search bar -->
    <form method="get" class="mb-3">
        <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Search by Title, Location, Status, or Department..." value="<?= htmlspecialchars($search) ?>">
            <button class="btn btn-primary" type="submit">Search</button>
            <?php if ($search): ?>
                <a href="list_cases.php" class="btn btn-secondary">Clear</a>
            <?php endif; ?>
        </div>
    </form>

    <?php if (empty($cases)): ?>
        <div class="alert alert-secondary">No cases found.</div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Title</th>
                        <th>Location</th>
                        <th>Status</th>
                        <th>Assigned Officer</th>
                        <th>Department</th>
                        <th>Case Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($cases as $c): ?>
                        <tr>
                            <td><?= htmlspecialchars($c['case_id']) ?></td>
                            <td><?= htmlspecialchars($c['title']) ?></td>
                            <td><?= htmlspecialchars($c['location'] ?: '—') ?></td>
                            <td>
                                <span class="badge bg-<?= $c['status']==='Open'?'success':($c['status']==='Under Investigation'?'warning text-dark':'secondary') ?>">
                                    <?= htmlspecialchars($c['status']) ?>
                                </span>
                            </td>
                            <td><?= htmlspecialchars($c['officer_name'] ?: '—') ?></td>
                            <td><?= htmlspecialchars($c['dept_name'] ?: '—') ?></td>
                            <td><?= htmlspecialchars($c['case_date'] ?: '—') ?></td>
                            <td>
                                <a href="view_case.php?id=<?= $c['case_id'] ?>" 
                                    class="btn btn-outline-primary btn-sm"
                                    style="padding: 2px 6px; font-size: 0.75rem;">
                                View
                                </a>

                                <?php if ($role === 'Admin' || ($role==='Officer' && $c['assigned_officer_id']==$officer_id)): ?>
                                    <a href="edit_case.php?id=<?= $c['case_id'] ?>" 
                                    class="btn btn-warning btn-sm"
                                    style="padding: 2px 6px; font-size: 0.75rem;">
                                    Edit
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php include "../includes/footer.php"; ?>
