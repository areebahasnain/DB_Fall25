<?php
// /arrests/edit_arrest.php
require_once "../config/database.php";
require_once "../includes/functions.php";
require_once "../includes/auth.php";

// Only Admins or assigned officers can edit an arrest
$role = $_SESSION['role'] ?? 'Analyst';
$user_id = $_SESSION['user_id'] ?? null;

// Get the arrest_id from GET or POST
$arrest_id = $_GET['arrest_id'] ?? $_POST['arrest_id'] ?? null;

if (!$arrest_id || !is_numeric($arrest_id)) {
    redirect("../cases/list_cases.php");
}

// Fetch existing arrest record
$stmt = $pdo->prepare("SELECT * FROM arrests WHERE arrest_id = ?");
$stmt->execute([$arrest_id]);
$arrest = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$arrest) {
    redirect("../cases/list_cases.php");
}

// Check permissions: Admin or officer assigned to the case
$can_edit = false;
if ($role === 'Admin') {
    $can_edit = true;
} elseif ($role === 'Officer') {
    $stmt2 = $pdo->prepare("SELECT officer_id FROM officers WHERE user_id = ?");
    $stmt2->execute([$user_id]);
    $officer = $stmt2->fetch();
    if ($officer && $officer['officer_id'] == $arrest['arresting_officer_id']) {
        $can_edit = true;
    }
}

if (!$can_edit) {
    die("Access denied.");
}

// Handle POST update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $criminal_id = $_POST['criminal_id'] ?? null;
    $arrest_date = $_POST['arrest_date'] ?? null;
    $arresting_officer_id = $_POST['arresting_officer_id'] ?: null; // optional
    $custody_status = $_POST['custody_status'] ?? 'In Custody';

    // Validation
    $errors = [];
    if (!$criminal_id || !is_numeric($criminal_id)) $errors[] = "Select a criminal.";
    if (!$arrest_date) $errors[] = "Arrest date is required.";
    if (!in_array($custody_status, ['In Custody', 'Released', 'Bail'])) $custody_status = 'In Custody';

    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("
                UPDATE arrests
                SET criminal_id = :criminal_id,
                    arrest_date = :arrest_date,
                    arresting_officer_id = :arresting_officer_id,
                    custody_status = :custody_status
                WHERE arrest_id = :arrest_id
            ");
            $stmt->execute([
                ':criminal_id' => $criminal_id,
                ':arrest_date' => $arrest_date,
                ':arresting_officer_id' => $arresting_officer_id,
                ':custody_status' => $custody_status,
                ':arrest_id' => $arrest_id
            ]);
            
            require_once "../../includes/functions_timeline.php";
            log_case_event($case_id, "Arrest updated", "Arrest for '$criminal_name' details updated.", 'Arrest', $_SESSION['user_id']);

            // **Set success message**
            $_SESSION['success'] = "Arrest updated successfully.";
            redirect("../cases/view_case.php?id={$arrest['case_id']}&tab=arrests");

        } catch (PDOException $e) {
            error_log("Edit Arrest Error: " . $e->getMessage());
            $errors[] = "Database error, please try again.";
        }
    }

    if (!empty($errors)) {
        $_SESSION['errors'] = $errors;
        redirect("../cases/view_case.php?id={$arrest['case_id']}&tab=arrests");
    }
}

// Fetch criminals and officers for select dropdowns
$criminals = $pdo->query("SELECT criminal_id, name FROM criminals ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
$officers = $pdo->query("SELECT officer_id, full_name FROM officers ORDER BY full_name ASC")->fetchAll(PDO::FETCH_ASSOC);
?>
