<?php
// /arrests/delete_arrest.php
require_once "../config/database.php";
require_once "../includes/functions.php";
require_once "../includes/auth.php";

// Only Admins or assigned officers can delete an arrest
$role = $_SESSION['role'] ?? 'Analyst';
$user_id = $_SESSION['user_id'] ?? null;

// Get arrest_id and case_id from query parameters
$arrest_id = $_GET['arrest_id'] ?? null;
$case_id   = $_GET['case_id'] ?? null;

if (!$arrest_id || !is_numeric($arrest_id) || !$case_id || !is_numeric($case_id)) {
    redirect("../cases/list_cases.php");
}

// Fetch the arrest record to check permissions
$stmt = $pdo->prepare("SELECT * FROM arrests WHERE arrest_id = ?");
$stmt->execute([$arrest_id]);
$arrest = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$arrest) {
    redirect("../cases/view_case.php?id={$case_id}&tab=arrests");
}

// Check permissions: Admin or officer assigned to the arrest
$can_delete = false;
if ($role === 'Admin') {
    $can_delete = true;
} elseif ($role === 'Officer') {
    $stmt2 = $pdo->prepare("SELECT officer_id FROM officers WHERE user_id = ?");
    $stmt2->execute([$user_id]);
    $officer = $stmt2->fetch();
    if ($officer && $officer['officer_id'] == $arrest['arresting_officer_id']) {
        $can_delete = true;
    }
}

if (!$can_delete) {
    die("Access denied.");
}

// Perform deletion
try {
    $stmt = $pdo->prepare("DELETE FROM arrests WHERE arrest_id = ?");
    $stmt->execute([$arrest_id]);
    
    require_once "../../includes/functions_timeline.php";
    log_case_event($case_id, "Arrest deleted", "Arrest record of '$criminal_name' deleted.", 'Arrest', $_SESSION['user_id']);

    // Success message
    $_SESSION['success'] = "Arrest deleted successfully.";
    redirect("../cases/view_case.php?id={$case_id}&tab=arrests");

} catch (PDOException $e) {
    error_log("Delete Arrest Error: " . $e->getMessage());
    $_SESSION['error'] = "Could not delete arrest. Please try again.";
    redirect("../cases/view_case.php?id={$case_id}&tab=arrests");
}
?>
