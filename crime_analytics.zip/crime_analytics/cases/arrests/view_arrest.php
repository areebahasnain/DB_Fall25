<?php
// /arrests/view_arrest.php
require_once "../config/database.php";
require_once "../includes/functions.php";
require_once "../includes/auth.php";

// Get the arrest ID
$arrest_id = $_GET['arrest_id'] ?? null;
if (!$arrest_id || !is_numeric($arrest_id)) {
    redirect("../cases/list_cases.php");
}

// Fetch the arrest record along with related data
$stmt = $pdo->prepare("
    SELECT a.*, 
           c.name AS criminal_name, 
           o.full_name AS arresting_officer_name, 
           ca.title AS case_title
    FROM arrests a
    LEFT JOIN criminals c ON a.criminal_id = c.criminal_id
    LEFT JOIN officers o ON a.arresting_officer_id = o.officer_id
    LEFT JOIN cases ca ON a.case_id = ca.case_id
    WHERE a.arrest_id = ?
");
$stmt->execute([$arrest_id]);
$arrest = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$arrest) {
    redirect("../cases/list_cases.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Arrest #<?= $arrest['arrest_id'] ?></title>
    <link href="../assets/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-4">

<div class="container">

    <h3>Arrest Details</h3>
    <hr>

    <p><strong>Case:</strong> <?= htmlspecialchars($arrest['case_title'] ?? 'N/A') ?> (ID: <?= $arrest['case_id'] ?>)</p>
    <p><strong>Arrest ID:</strong> <?= $arrest['arrest_id'] ?></p>
    <p><strong>Criminal:</strong> <?= htmlspecialchars($arrest['criminal_name']) ?></p>
    <p><strong>Arresting Officer:</strong> <?= $arrest['arresting_officer_name'] ? htmlspecialchars($arrest['arresting_officer_name']) : 'N/A' ?></p>
    <p><strong>Arrest Date:</strong> <?= $arrest['arrest_date'] ? date("F j, Y", strtotime($arrest['arrest_date'])) : '—' ?></p>
    <p><strong>Custody Status:</strong> 
        <span class="badge <?= $arrest['custody_status'] === 'In Custody' ? 'bg-success' : ($arrest['custody_status'] === 'Bail' ? 'bg-warning text-dark' : 'bg-secondary') ?>">
            <?= htmlspecialchars($arrest['custody_status']) ?>
        </span>
    </p>

    <a href="../cases/view_case.php?id=<?= $arrest['case_id'] ?>&tab=arrests" class="btn btn-secondary mt-3">
        Back to Case
    </a>
</div>

<script src="../assets/bootstrap.bundle.min.js"></script>
</body>
</html>
