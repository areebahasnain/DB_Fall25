<?php
// /arrests/add_arrest.php
require_once "../../config/database.php";
require_once "../../includes/functions.php";
require_once "../../includes/auth.php";

// Only Admins or assigned officers can add an arrest
$role = $_SESSION['role'] ?? 'Analyst';
$user_id = $_SESSION['user_id'] ?? null;

// Validate POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $case_id = $_POST['case_id'] ?? null;
    $criminal_id = $_POST['criminal_id'] ?? null;
    $arrest_date = $_POST['arrest_date'] ?? null;
    $arresting_officer_id = $_POST['arresting_officer_id'] ?: null; // optional
    $custody_status = $_POST['custody_status'] ?? 'In Custody';

    // Simple validation
    $errors = [];
    if (!$case_id || !is_numeric($case_id)) $errors[] = "Invalid case.";
    if (!$criminal_id || !is_numeric($criminal_id)) $errors[] = "Select a criminal.";
    if (!$arrest_date) $errors[] = "Arrest date is required.";
    if (!in_array($custody_status, ['In Custody','Released','Bail'])) $custody_status = 'In Custody';

    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO arrests (case_id, criminal_id, arrest_date, arresting_officer_id, custody_status)
                VALUES (:case_id, :criminal_id, :arrest_date, :arresting_officer_id, :custody_status)
            ");
            $stmt->execute([
                ':case_id' => $case_id,
                ':criminal_id' => $criminal_id,
                ':arrest_date' => $arrest_date,
                ':arresting_officer_id' => $arresting_officer_id,
                ':custody_status' => $custody_status
            ]);

            require_once "../../includes/functions_timeline.php";
            log_case_event($case_id, "Arrest added", "Arrest for '$criminal_name' recorded.", 'Arrest', $_SESSION['user_id']);


            $_SESSION['success'] = "Arrest added successfully.";
            redirect("../cases/view_case.php?id={$case_id}&tab=arrests");

        } catch (PDOException $e) {
            error_log("Add Arrest Error: " . $e->getMessage());
            $_SESSION['error'] = "Database error, please try again.";
            redirect("../cases/view_case.php?id={$case_id}&tab=arrests");
        }
    } else {
        // If validation errors exist
        $_SESSION['errors'] = $errors;
        redirect("../cases/view_case.php?id={$case_id}&tab=arrests");
    }
} else {
    // Block direct access
    redirect("../cases/list_cases.php");
}
