<?php
require_once "../config/database.php";
require_once "../includes/functions.php";
require_once "../includes/auth.php";

// Only Admin can edit
require_role('Admin');

// Validate ID
if (!isset($_GET['id'])) {
    redirect('list_departments.php');
}

$dept_id = (int)$_GET['id'];

// Fetch department
$stmt = $pdo->prepare("SELECT * FROM departments WHERE department_id = ?");
$stmt->execute([$dept_id]);
$department = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$department) {
    die("Department not found.");
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name']);

    if ($name === '') {
        $error = "Department name cannot be empty.";
    } else {
        // Update department
        $stmt = $pdo->prepare("UPDATE departments SET name = ? WHERE department_id = ?");
        $stmt->execute([$name, $dept_id]);

        $_SESSION['success'] = "Department updated successfully.";
        redirect('list_departments.php');
    }
}
?>

<?php include "../includes/header.php"; ?>

<div class="container mt-4">
    <div class="card p-4 shadow">
        <h3>Edit Department</h3>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="post">
            <div class="mb-3">
                <label class="form-label">Department Name</label>
                <input type="text" name="name" class="form-control" 
                       value="<?= htmlspecialchars($department['name']) ?>" required>
            </div>

            <button type="submit" class="btn btn-dark">Update</button>
            <a href="list_departments.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</div>

<?php include "../includes/footer.php"; ?>
