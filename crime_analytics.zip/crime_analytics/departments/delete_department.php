<?php
require_once "../config/database.php";
require_once "../includes/functions.php";
require_once "../includes/auth.php";

// Only Admin can delete
require_role('Admin');

// Check dept ID
if (!isset($_GET['id'])) {
    redirect('list_departments.php');
}

$dept_id = (int)$_GET['id'];

// 1) Check if officers exist under this department
$stmt = $pdo->prepare("SELECT COUNT(*) FROM officers WHERE department_id = ?");
$stmt->execute([$dept_id]);
$officer_count = $stmt->fetchColumn();

// 2) Check if cases exist under this department
$stmt2 = $pdo->prepare("SELECT COUNT(*) FROM cases WHERE department_id = ?");
$stmt2->execute([$dept_id]);
$case_count = $stmt2->fetchColumn();

if ($officer_count > 0) {
    $_SESSION['error'] = "Cannot delete department. $officer_count officer(s) are assigned to it.";
    redirect("list_departments.php");
}

if ($case_count > 0) {
    $_SESSION['error'] = "Cannot delete department. $case_count case(s) belong to this department.";
    redirect("list_departments.php");
}

// 3) Safe to delete
$stmt = $pdo->prepare("DELETE FROM departments WHERE department_id = ?");
$stmt->execute([$dept_id]);

$_SESSION['success'] = "Department deleted successfully.";
redirect("list_departments.php");
