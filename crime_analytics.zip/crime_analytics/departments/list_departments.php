<?php
require_once "../config/database.php";
require_once "../includes/functions.php";
require_once "../includes/auth.php";

// Only Admin and Officer can view
if (!in_array($_SESSION['role'], ['Admin','Officer'])) {
    die("Access denied");
}

// Handle search
$search = trim($_GET['search'] ?? '');
$params = [];
$where = '';

if ($search) {
    $where = " WHERE name LIKE ?";
    $params = ["%$search%"];
}

// Fetch departments
$sql = "
    SELECT department_id, name
    FROM departments
    $where
    ORDER BY department_id ASC
";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$departments = $stmt->fetchAll();

// Flash message
$flash_success = '';
if (isset($_SESSION['success'])) {
    $flash_success = $_SESSION['success'];
    unset($_SESSION['success']);
}
?>

<?php include "../includes/header.php"; ?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Departments</h2>
        <?php if ($_SESSION['role'] === 'Admin'): ?>
            <a href="add_department.php" class="btn btn-dark">Add Department</a>
        <?php endif; ?>
    </div>

    <?php if ($flash_success): ?>
        <div class="alert alert-success"><?= $flash_success ?></div>
    <?php endif; ?>

    <!-- Search Bar -->
    <form method="get" class="mb-3">
        <div class="input-group">
            <input type="text" name="search" class="form-control"
                   placeholder="Search by Department Name..."
                   value="<?= htmlspecialchars($search) ?>">
            <button class="btn btn-primary" type="submit">Search</button>
            <?php if ($search): ?>
                <a href="list_departments.php" class="btn btn-secondary">Clear</a>
            <?php endif; ?>
        </div>
    </form>

    <table class="table table-striped table-hover">
        <thead class="table-dark">
            <tr>
                <th>#</th>
                <th>Department Name</th>
                <?php if ($_SESSION['role'] === 'Admin'): ?>
                    <th>Actions</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
        <?php if ($departments): ?>
            <?php foreach ($departments as $dept): ?>
                <tr>
                    <td><?= $dept['department_id'] ?></td>
                    <td><?= htmlspecialchars($dept['name']) ?></td>
                    <?php if ($_SESSION['role'] === 'Admin'): ?>
                    <td>
                        <a href="edit_department.php?id=<?= $dept['department_id'] ?>" class="btn btn-sm btn-primary">Edit</a>
                        <a href="delete_department.php?id=<?= $dept['department_id'] ?>"
                           class="btn btn-sm btn-danger"
                           onclick="return confirm('Delete this department? Officers will have no department assigned.')">
                           Delete
                        </a>
                    </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="<?= $_SESSION['role'] === 'Admin' ? 3 : 2 ?>" class="text-center">
                    No departments found.
                </td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include "../includes/footer.php"; ?>
