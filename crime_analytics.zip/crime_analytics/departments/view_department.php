<?php
require_once "../config/database.php";
require_once "../includes/functions.php";
require_once "../includes/auth.php";

// Admin only
require_role('Admin');

if (!isset($_GET['id'])) {
    redirect('list_departments.php');
}

$dept_id = (int)$_GET['id'];

// Fetch department info
$dept_stmt = $pdo->prepare("SELECT * FROM departments WHERE id = ?");
$dept_stmt->execute([$dept_id]);
$department = $dept_stmt->fetch();

if (!$department) {
    redirect('list_departments.php');
}

// Fetch officers in this department
$officer_stmt = $pdo->prepare("
    SELECT o.officer_id, u.full_name, o.rank, o.contact
    FROM officers o
    JOIN users u ON o.user_id = u.user_id
    WHERE o.department_id = ?
");
$officer_stmt->execute([$dept_id]);
$officers = $officer_stmt->fetchAll();

// Fetch cases in this department
$cases_stmt = $pdo->prepare("
    SELECT case_id, title, status
    FROM cases
    WHERE department_id = ?
    ORDER BY case_id DESC
");
$cases_stmt->execute([$dept_id]);
$cases = $cases_stmt->fetchAll();
?>

<?php include "../includes/header.php"; ?>

<div class="container py-4">

    <div class="card shadow p-4">
        <h3>Department: <?= htmlspecialchars($department['name']) ?></h3>

        <p><strong>Officers:</strong> <?= count($officers) ?></p>
        <p><strong>Cases:</strong> <?= count($cases) ?></p>

        <hr>

        <h4>Officers in this Department</h4>
        <?php if (count($officers) === 0): ?>
            <p class="text-muted">No officers assigned.</p>
        <?php else: ?>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Full Name</th>
                        <th>Rank</th>
                        <th>Contact</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($officers as $o): ?>
                        <tr>
                            <td><?= htmlspecialchars($o['full_name']) ?><_]()
