<?php
require_once "../config/database.php";
require_once "../includes/functions.php";
require_once "../includes/auth.php";

// Only Admin can add
require_role('Admin');

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name']);

    if ($name === '') {
        $error = "Department name cannot be empty.";
    } else {
        // Insert department
        $stmt = $pdo->prepare("INSERT INTO departments (name) VALUES (?)");

        try {
            $stmt->execute([$name]);
            $_SESSION['success'] = "Department added successfully.";
            redirect("list_departments.php");
        } catch (PDOException $e) {
            $error = "Error: Department already exists or invalid.";
        }
    }
}
?>

<?php include "../includes/header.php"; ?>

<div class="container mt-4">
    <div class="card p-4 shadow">
        <h3>Add Department</h3>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>

        <form method="post">
            <div class="mb-3">
                <label class="form-label">Department Name</label>
                <input type="text" name="name" class="form-control" placeholder="e.g., Cyber Crime, Homicide" required>
            </div>

            <button type="submit" class="btn btn-dark">Add Department</button>
            <a href="list_departments.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</div>

<?php include "../includes/footer.php"; ?>
