<?php
require_once "config/database.php";
require_once "includes/auth.php";
require_once "includes/functions.php";

// Example role-based data fetch
$user_role = $_SESSION['role'] ?? 'Analyst';

// Fetch counts for cards
$open_case_count = $pdo->query("SELECT COUNT(*) FROM cases WHERE status='Open'")->fetchColumn();
$wanted_count = $pdo->query("SELECT COUNT(*) FROM criminals WHERE status='Wanted'")->fetchColumn();
$arrest_count = $pdo->query("SELECT COUNT(*) FROM arrests")->fetchColumn();
$active_officer_count = $pdo->query("SELECT COUNT(*) FROM officers")->fetchColumn();
?>

<?php include "includes/header.php"; ?>

<div class="container py-4">

    <div class="hero-text mb-4">
        <h1>Welcome to Crime Analytics</h1>
        <p>Select an option from the navigation bar.</p>
    </div>

    <div class="row g-3">
        <?php if($user_role == 'Admin'): ?>
        <div class="col-md-3">
            <div class="card p-3 shadow-sm text-center">
                <i class="bi bi-file-earmark-text display-4 mb-2"></i>
                <h5>Open Cases</h5>
                <h3><?= $open_case_count ?></h3>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card p-3 shadow-sm text-center">
                <i class="bi bi-exclamation-triangle-fill display-4 mb-2"></i>
                <h5>Wanted Criminals</h5>
                <h3><?= $wanted_count ?></h3>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card p-3 shadow-sm text-center">
                <i class="bi bi-person-check-fill display-4 mb-2"></i>
                <h5>Recent Arrests</h5>
                <h3><?= $arrest_count ?></h3>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card p-3 shadow-sm text-center">
                <i class="bi bi-shield-lock-fill display-4 mb-2"></i>
                <h5>Active Officers</h5>
                <h3><?= $active_officer_count ?></h3>
            </div>
        </div>

        <?php elseif($user_role == 'Officer'): ?>
        <div class="col-md-4">
            <div class="card p-3 shadow-sm text-center">
                <i class="bi bi-file-earmark-text display-4 mb-2"></i>
                <h5>Your Open Cases</h5>
                <h3><?= $open_case_count ?></h3>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card p-3 shadow-sm text-center">
                <i class="bi bi-exclamation-triangle-fill display-4 mb-2"></i>
                <h5>Wanted Criminals Assigned</h5>
                <h3><?= $wanted_count ?></h3>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card p-3 shadow-sm text-center">
                <i class="bi bi-person-check-fill display-4 mb-2"></i>
                <h5>Your Recent Arrests</h5>
                <h3><?= $arrest_count ?></h3>
            </div>
        </div>

        <?php else: // Analyst ?>
        <div class="col-md-4">
            <div class="card p-3 shadow-sm text-center">
                <i class="bi bi-file-earmark-text display-4 mb-2"></i>
                <h5>Total Open Cases</h5>
                <h3><?= $open_case_count ?></h3>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card p-3 shadow-sm text-center">
                <i class="bi bi-exclamation-triangle-fill display-4 mb-2"></i>
                <h5>Total Wanted Criminals</h5>
                <h3><?= $wanted_count ?></h3>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card p-3 shadow-sm text-center">
                <i class="bi bi-person-check-fill display-4 mb-2"></i>
                <h5>Total Arrests</h5>
                <h3><?= $arrest_count ?></h3>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <!-- Placeholder for charts -->
    <div class="row mt-4">
        <div class="col-md-12">
            <div class="card p-3 shadow-sm">
                <h5>Crime Trends</h5>
                <canvas id="crimeTrendsChart" height="150"></canvas>
            </div>
        </div>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const ctx = document.getElementById('crimeTrendsChart').getContext('2d');
new Chart(ctx, {
    type: 'line',
    data: {
        labels: ['Jan','Feb','Mar','Apr','May'],
        datasets: [{
            label: 'Cases',
            data: [12,19,7,15,10],
            borderColor: 'var(--accent)',
            backgroundColor: 'rgba(23,162,184,0.2)',
            fill: true
        }]
    },
    options: { responsive:true }
});
</script>

<?php include "includes/footer.php"; ?>
