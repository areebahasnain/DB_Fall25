<?php
require_once "../config/database.php";
require_once "../includes/functions.php";
require_once "../includes/auth.php";

require_role('Admin');

// Modal vars
$temp_password = "";
$show_modal = false;
$redirect_after = "";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = sanitize($_POST['full_name']);
    $username = sanitize($_POST['username']);
    $role = sanitize($_POST['role']);

    // Basic validation
    if ($full_name === "" || $username === "" || $role === "") {
        $error = "All fields are required.";
    } else {
        // Check username exists
        $stmt = $pdo->prepare("SELECT user_id FROM users WHERE username = ?");
        $stmt->execute([$username]);

        if ($stmt->rowCount() > 0) {
            $error = "Username already exists.";
        } else {
            // Generate temporary password
            $temp_password = bin2hex(random_bytes(4)) . "!" . rand(10, 99); 
            $hash = password_hash($temp_password, PASSWORD_BCRYPT);

            // Insert user
            $insert = $pdo->prepare("INSERT INTO users (username, password_hash, role, full_name) VALUES (?, ?, ?, ?)");
            $insert->execute([$username, $hash, $role, $full_name]);

            // Show modal
            $show_modal = true;

            // Redirect after modal
            $redirect_after = ($role === "Officer")
                ? "/crime_analytics/officers/add_officer.php?username=" . urlencode($username)
                : "/crime_analytics/users/list_users.php";
        }
    }
}

include "../includes/header.php";
?>

<div class="container py-4">
    <div class="card shadow p-4">
        <h3>Add New User</h3>

        <?php if (!empty($error)): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Full Name</label>
                <input type="text" name="full_name" class="form-control" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Username</label>
                <input type="text" name="username" class="form-control" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Role</label>
                <select name="role" class="form-control" required>
                    <option value="">Select Role</option>
                    <option value="Admin">Admin</option>
                    <option value="Officer">Officer</option>
                    <option value="Analyst">Analyst</option>
                </select>
            </div>

            <button type="submit" class="btn btn-primary">Create User</button>
            <a href="list_users.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</div>

<?php if ($show_modal): ?>
<!-- ============================ MODAL =========================== -->
<div class="modal fade show" id="passwordModal" tabindex="-1" style="display:block; background:rgba(0,0,0,0.5);">
    <div class="modal-dialog">
        <div class="modal-content p-3" style="color:#000;"> <!-- Ensure all text black -->
            <div class="modal-header">
                <h5 class="modal-title">User Created Successfully</h5>
            </div>
            <div class="modal-body text-center" style="color:#000;">
                <p><strong>Temporary Password:</strong></p>
                <div class="alert alert-dark" style="font-size:1.4rem; font-weight:bold; color:#000;">
                    <?= htmlspecialchars($temp_password) ?>
                </div>
                <p style="color:#000;">Please copy this password now. It will not be shown again.</p>
            </div>
            <div class="modal-footer justify-content-center">
                <a href="<?= $redirect_after ?>" class="btn btn-primary">Continue</a>
            </div>
        </div>
    </div>
</div>

<script>
    // Prevent body scrolling while modal is open
    document.body.classList.add('modal-open');
</script>
<?php endif; ?>

<?php include "../includes/footer.php"; ?>
