<?php
require_once "../config/database.php";
require_once "../includes/functions.php";
require_once "../includes/auth.php";

// Only Admin can edit users
require_role('Admin');

// Check ID
if (!isset($_GET['id'])) {
    redirect("list_users.php");
}

$user_id = (int)$_GET['id'];

// Fetch user
$stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user) {
    redirect("list_users.php");
}

$error = '';
$success = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $full_name = sanitize($_POST['full_name']);
    $username = sanitize($_POST['username']);
    $role = sanitize($_POST['role']);
    $password = $_POST['password']; // Don't sanitize yet (hash required)

    // Validate required fields
    if ($full_name === '' || $username === '' || $role === '') {
        $error = "Full name, username, and role are required.";
    } else {
        // Prevent admin from changing their own role
        if ($user_id == $_SESSION['user_id'] && $role !== $user['role']) {
            $error = "You cannot change your own role.";
        } else {
            // Check for duplicate username
            $check = $pdo->prepare("SELECT user_id FROM users WHERE username = ? AND user_id != ?");
            $check->execute([$username, $user_id]);

            if ($check->fetch()) {
                $error = "Username is already taken.";
            } else {
                // Update logic
                if (!empty($password)) {
                    // Update including password
                    $password_hash = password_hash($password, PASSWORD_BCRYPT);

                    $update = $pdo->prepare("
                        UPDATE users 
                        SET full_name = ?, username = ?, role = ?, password_hash = ?
                        WHERE user_id = ?
                    ");
                    $update->execute([$full_name, $username, $role, $password_hash, $user_id]);
                } else {
                    // Update without password
                    $update = $pdo->prepare("
                        UPDATE users 
                        SET full_name = ?, username = ?, role = ?
                        WHERE user_id = ?
                    ");
                    $update->execute([$full_name, $username, $role, $user_id]);
                }

                $_SESSION['success'] = "User updated successfully!";
                redirect("list_users.php");
            }
        }
    }
}

include "../includes/header.php";
?>

<div class="container py-4">
    <div class="card shadow p-4">
        <h3>Edit User: <?= htmlspecialchars($user['full_name']) ?></h3>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>

        <form method="POST">

            <div class="mb-3">
                <label class="form-label">Full Name</label>
                <input type="text" name="full_name" class="form-control"
                       value="<?= htmlspecialchars($user['full_name']) ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Username</label>
                <input type="text" name="username" class="form-control"
                       value="<?= htmlspecialchars($user['username']) ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Role</label>
                <select name="role" class="form-select" required>
                    <option value="Admin" <?= $user['role'] == 'Admin' ? 'selected' : '' ?>>Admin</option>
                    <option value="Officer" <?= $user['role'] == 'Officer' ? 'selected' : '' ?>>Officer</option>
                    <option value="Analyst" <?= $user['role'] == 'Analyst' ? 'selected' : '' ?>>Analyst</option>
                </select>
                <?php if ($user['user_id'] == $_SESSION['user_id']): ?>
                    <small class="text-danger">You cannot change your own role.</small>
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <label class="form-label">New Password (optional)</label>
                <input type="password" name="password" class="form-control" placeholder="Leave blank to keep unchanged">
            </div>

            <button type="submit" class="btn btn-primary">Update User</button>
            <a href="list_users.php" class="btn btn-secondary">Cancel</a>

        </form>
    </div>
</div>

<?php include "../includes/footer.php"; ?>
