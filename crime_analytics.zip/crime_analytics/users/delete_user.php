<?php
require_once "../config/database.php";
require_once "../includes/functions.php";
require_once "../includes/auth.php";

// Only Admin can delete users
require_role('Admin');

// Make sure user_id is provided
if (!isset($_GET['id'])) {
    redirect("list_users.php");
}

$user_id = (int)$_GET['id'];

// Fetch user data
$stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user) {
    redirect("list_users.php");
}

// ⛔ Prevent deleting yourself
if ($user_id == $_SESSION['user_id']) {
    $_SESSION['error'] = "You cannot delete your own account.";
    redirect("list_users.php");
}

// OPTIONAL: check if this user is linked to an officer
$checkOfficer = $pdo->prepare("SELECT officer_id FROM officers WHERE user_id = ?");
$checkOfficer->execute([$user_id]);
$officerExists = $checkOfficer->fetch();

// If form submitted → delete user
if (isset($_POST['confirm'])) {

    // If linked to officer → delete officer first or block deletion
    if ($officerExists) {
        $_SESSION['error'] = "This user is linked to an officer. Delete the officer first.";
        redirect("list_users.php");
    }

    // Delete user
    $delete = $pdo->prepare("DELETE FROM users WHERE user_id = ?");
    $delete->execute([$user_id]);

    $_SESSION['success'] = "User '{$user['full_name']}' (Username: {$user['username']}) deleted successfully.";
    redirect("list_users.php");
}

include "../includes/header.php";
?>

<div class="container py-4">
    <div class="card shadow p-4">

        <h3>Delete User</h3>

        <div class="alert alert-warning">
            Are you sure you want to delete the following user?
            <br><br>

            <strong>Name:</strong> <?= htmlspecialchars($user['full_name']) ?><br>
            <strong>Username:</strong> <?= htmlspecialchars($user['username']) ?><br>
            <strong>Role:</strong> <?= htmlspecialchars($user['role']) ?>
        </div>

        <?php if ($officerExists): ?>
            <div class="alert alert-danger">
                This user is linked to an officer and <strong>cannot be deleted</strong> until that officer record is deleted.
            </div>
        <?php endif; ?>

        <form method="POST">
            <button type="submit" name="confirm" class="btn btn-danger" 
                <?= $officerExists ? "disabled" : "" ?>>
                Yes, Delete User
            </button>

            <a href="list_users.php" class="btn btn-secondary">Cancel</a>
        </form>

    </div>
</div>

<?php include "../includes/footer.php"; ?>
