<?php
require_once "../config/database.php";
require_once "../includes/functions.php";
require_once "../includes/auth.php";

require_role('Admin'); // only Admin can access

// Search
$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';

$query = "
    SELECT user_id, username, full_name, role, created_at
    FROM users
";

if (!empty($search)) {
    $query .= " WHERE full_name LIKE :search OR username LIKE :search OR role LIKE :search ";
}

// Change ordering to ascending by user_id
$query .= " ORDER BY user_id ASC";

$stmt = $pdo->prepare($query);

if (!empty($search)) {
    $stmt->bindValue(':search', "%$search%");
}

$stmt->execute();
$users = $stmt->fetchAll();

include "../includes/header.php";
?>

<div class="container py-4">

    <!-- Flash Message -->
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success">
            <?= $_SESSION['success']; unset($_SESSION['success']); ?>
        </div>
    <?php endif; ?>

    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Manage Users</h3>
        <a href="add_user.php" class="btn btn-dark">+ Add New User</a>
    </div>

    <!-- Search -->
    <form method="GET" class="mb-3">
        <input type="text" name="search" class="form-control" 
               placeholder="Search by name, username, or role..."
               value="<?= htmlspecialchars($search) ?>">
    </form>

    <div class="card shadow">
        <div class="card-body p-0">
            <table class="table table-hover mb-0">
                <thead class="table-dark">
                    <tr>
                        <th>#</th>
                        <th>Full Name</th>
                        <th>Username</th>
                        <th>Role</th>
                        <th>Created</th>
                        <th style="width: 130px;">Actions</th>
                    </tr>
                </thead>
                <tbody>

                <?php if (count($users) === 0): ?>
                    <tr>
                        <td colspan="6" class="text-center p-3 text-muted">No users found.</td>
                    </tr>

                <?php else: ?>
                    <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?= $user['user_id'] ?></td>
                            <td><?= htmlspecialchars($user['full_name']) ?></td>
                            <td><?= htmlspecialchars($user['username']) ?></td>
                            <td><span class="badge bg-secondary"><?= $user['role'] ?></span></td>
                            <td><?= date("Y-m-d", strtotime($user['created_at'])) ?></td>

                            <td>

                                <a href="edit_user.php?id=<?= $user['user_id'] ?>" 
                                   class="btn btn-sm btn-primary">
                                    Edit
                                </a>

                                <!-- Delete Button triggers Modal -->
                                <button class="btn btn-sm btn-danger"
                                        data-bs-toggle="modal"
                                        data-bs-target="#deleteModal<?= $user['user_id'] ?>">
                                    Delete
                                </button>

                                <!-- Delete Confirmation Modal -->
                                <div class="modal fade" id="deleteModal<?= $user['user_id'] ?>" tabindex="-1">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Delete User</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>

                                            <div class="modal-body">
                                                Are you sure you want to delete user 
                                                <strong><?= htmlspecialchars($user['full_name']) ?></strong>?
                                            </div>

                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>

                                                <a href="delete_user.php?id=<?= $user['user_id'] ?>" 
                                                   class="btn btn-danger">
                                                    Delete
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                            </td>
                        </tr>

                    <?php endforeach; ?>
                <?php endif; ?>

                </tbody>
            </table>
        </div>
    </div>

</div>

<?php include "../includes/footer.php"; ?>
