<?php
require_once "../config/database.php";
require_once "../includes/functions.php";
require_once "../includes/auth.php";

// Only Admin can edit
require_role('Admin');

if (!isset($_GET['id'])) {
    redirect('list_officers.php');
}

$officer_id = (int)$_GET['id'];

// Fetch officer info
$stmt = $pdo->prepare("
    SELECT o.officer_id, o.rank, o.cnic, o.department_id, o.photo, u.full_name AS user_name, u.username
    FROM officers o
    JOIN users u ON o.user_id = u.user_id
    WHERE o.officer_id = ?
");
$stmt->execute([$officer_id]);
$officer = $stmt->fetch();

if (!$officer) {
    redirect('list_officers.php');
}

// Fetch departments for dropdown
$dept_stmt = $pdo->query("SELECT department_id, name FROM departments ORDER BY name ASC");
$departments = $dept_stmt->fetchAll();

$error = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rank = sanitize($_POST['rank']);
    $cnic = sanitize($_POST['cnic']);
    $department_id = !empty($_POST['department_id']) ? (int)$_POST['department_id'] : null;

    // Start with current photo
    $photo_name = $officer['photo'];

    // Handle new photo upload if provided
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
        $allowed_types = ['image/jpeg','image/png','image/gif'];
        if (!in_array($_FILES['photo']['type'], $allowed_types)) {
            $error = "Photo must be JPG, PNG, or GIF.";
        } else {
            // Delete old photo if exists
            if (!empty($officer['photo']) && file_exists("../uploads/officers/" . $officer['photo'])) {
                unlink("../uploads/officers/" . $officer['photo']);
            }
            // Save new photo
            $ext = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
            $photo_name = uniqid('officer_') . '.' . $ext;
            move_uploaded_file($_FILES['photo']['tmp_name'], "../uploads/officers/" . $photo_name);
        }
    }

    // Validation
    if ($rank === '' || $cnic === '') {
        $error = "Rank and CNIC cannot be empty.";
    } elseif (!preg_match('/^\d{5}-\d{7}-\d{1}$/', $cnic)) {
        $error = "CNIC must be in the format xxxxx-xxxxxxx-x.";
    }

    // Update officer if no error
    if (!$error) {
        $update_stmt = $pdo->prepare("
            UPDATE officers
            SET rank = ?, cnic = ?, department_id = ?, photo = ?
            WHERE officer_id = ?
        ");
        $update_stmt->execute([$rank, $cnic, $department_id, $photo_name, $officer_id]);

        $_SESSION['success'] = "Officer updated successfully";
        redirect('list_officers.php');
    }
}
?>

<?php include "../includes/header.php"; ?>

<div class="container py-4">
    <div class="card p-4 shadow">
        <h3>Edit Officer: <?= htmlspecialchars($officer['user_name']) ?></h3>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>

        <form method="post" enctype="multipart/form-data">
            <div class="mb-3">
                <label class="form-label">Rank</label>
                <input type="text" name="rank" class="form-control" value="<?= htmlspecialchars($officer['rank']) ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label">CNIC</label>
                <input type="text" name="cnic" class="form-control" value="<?= htmlspecialchars($officer['cnic']) ?>" placeholder="xxxxx-xxxxxxx-x" required>
                <small class="text-muted">Format: 12345-1234567-1</small>
            </div>

            <div class="mb-3">
                <label class="form-label">Department</label>
                <select name="department_id" class="form-control">
                    <option value="">— None —</option>
                    <?php foreach ($departments as $dept): ?>
                        <option value="<?= $dept['department_id'] ?>" <?= $officer['department_id'] == $dept['department_id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($dept['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Photo</label><br>
                <?php if (!empty($officer['photo']) && file_exists("../uploads/officers/" . $officer['photo'])): ?>
                    <img src="../uploads/officers/<?= $officer['photo'] ?>" alt="Officer Photo" class="img-thumbnail mb-2" style="max-width:150px;"><br>
                <?php else: ?>
                    <img src="../assets/default_officer.png" alt="Default Officer" class="img-thumbnail mb-2" style="max-width:150px;"><br>
                <?php endif; ?>
                <input type="file" name="photo" class="form-control">
                <small class="text-muted">Upload JPG, PNG, or GIF. Leave empty to keep existing or default photo.</small>
            </div>

            <button type="submit" class="btn btn-primary">Update Officer</button>
            <a href="list_officers.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</div>

<?php include "../includes/footer.php"; ?>
