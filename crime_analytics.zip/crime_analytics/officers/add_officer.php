<?php
require_once "../config/database.php";
require_once "../includes/functions.php";
require_once "../includes/auth.php";

// Only Admin can add officers
require_role('Admin');

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize input
    $user_id = sanitize($_POST['user_id']);
    $rank = sanitize($_POST['rank']);
    $cnic_no = sanitize($_POST['cnic_no']);
    $department_id = !empty($_POST['department_id']) ? (int)$_POST['department_id'] : null;

    // Validate CNIC format
    if (!preg_match('/^[0-9]{5}-[0-9]{7}-[0-9]{1}$/', $cnic_no)) {
        $error = "CNIC must be in the format xxxxx-xxxxxxx-x.";
    } elseif (empty($user_id)) {
        $error = "Please select a user to assign as officer.";
    } elseif ($rank === '') {
        $error = "Rank cannot be empty.";
    } else {
        $file_name = null; // Default if no photo uploaded

        // Handle file upload if provided
        if (!empty($_FILES['photo']['name']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = '../uploads/officers/';
            if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

            $file_ext = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
            $allowed_ext = ['jpg','jpeg','png','gif'];

            if (!in_array($file_ext, $allowed_ext)) {
                $error = "Only JPG, PNG, GIF files are allowed for photo.";
            } else {
                $file_name = uniqid('officer_') . '.' . $file_ext;
                $file_path = $upload_dir . $file_name;

                if (!move_uploaded_file($_FILES['photo']['tmp_name'], $file_path)) {
                    $error = "Failed to upload photo.";
                    $file_name = null;
                }
            }
        }

        // If no error, insert officer
        if (!$error) {
            $stmt = $pdo->prepare("INSERT INTO officers (user_id, rank, cnic, department_id, photo) VALUES (?, ?, ?, ?, ?)");
            try {
                $stmt->execute([$user_id, $rank, $cnic_no, $department_id, $file_name]);
                $_SESSION['success'] = "Officer added successfully!";
                redirect('list_officers.php');
            } catch (PDOException $e) {
                $error = "Error: " . $e->getMessage();
                if (!empty($file_path) && file_exists($file_path)) unlink($file_path);
            }
        }
    }
}

// Fetch all users who are not yet assigned as officers
$users_stmt = $pdo->query("
    SELECT user_id, full_name, username 
    FROM users 
    WHERE user_id NOT IN (SELECT user_id FROM officers)
");
$available_users = $users_stmt->fetchAll();

// Fetch departments
$dept_stmt = $pdo->query("SELECT department_id, name FROM departments");
$departments = $dept_stmt->fetchAll();
?>

<?php include "../includes/header.php"; ?>

<div class="container mt-4">
    <h2>Add Officer</h2>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="user_id" class="form-label">Assign User</label>
            <select name="user_id" class="form-select" required>
                <option value="">-- Select User --</option>
                <?php foreach ($available_users as $user): ?>
                    <option value="<?= $user['user_id'] ?>">
                        <?= $user['full_name'] ?> (<?= $user['username'] ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="rank" class="form-label">Rank</label>
            <input type="text" name="rank" class="form-control" placeholder="e.g., Inspector" required>
        </div>

        <div class="mb-3">
            <label for="cnic_no" class="form-label">CNIC <span class="text-danger">*</span></label>
            <input type="text" name="cnic_no" class="form-control" placeholder="xxxxx-xxxxxxx-x" pattern="\d{5}-\d{7}-\d{1}" required>
        </div>

        <div class="mb-3">
            <label for="department_id" class="form-label">Department</label>
            <select name="department_id" class="form-select">
                <option value="">-- None --</option>
                <?php foreach ($departments as $dept): ?>
                    <option value="<?= $dept['department_id'] ?>"><?= $dept['name'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="photo" class="form-label">Officer Photo</label>
            <input type="file" name="photo" class="form-control">
            <small class="text-muted">Optional: Upload later if needed</small>
        </div>

        <button type="submit" class="btn btn-dark">Add Officer</button>
    </form>
</div>

<?php include "../includes/footer.php"; ?>
