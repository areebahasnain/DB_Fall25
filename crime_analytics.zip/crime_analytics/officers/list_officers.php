<?php
require_once "../config/database.php";
require_once "../includes/functions.php";
require_once "../includes/auth.php";

// Only Admin can view full list
require_role('Admin');

// Handle search
$search = trim($_GET['search'] ?? '');
$params = [];
$where = '';

if ($search) {
    $where = " WHERE u.full_name LIKE ? OR u.username LIKE ? OR o.rank LIKE ? OR o.cnic LIKE ? OR d.name LIKE ?";
    $params = ["%$search%", "%$search%", "%$search%", "%$search%", "%$search%"];
}

// Fetch all officers with user info and department
$sql = "
    SELECT o.officer_id, u.full_name AS user_name, u.username, o.rank, o.cnic, o.photo, d.name AS dept_name
    FROM officers o
    JOIN users u ON o.user_id = u.user_id
    LEFT JOIN departments d ON o.department_id = d.department_id
    $where
    ORDER BY o.officer_id ASC
";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$officers = $stmt->fetchAll();

// Handle flash messages
$flash_success = '';
if (isset($_SESSION['success'])) {
    $flash_success = $_SESSION['success'];
    unset($_SESSION['success']);
}
?>

<?php include "../includes/header.php"; ?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Officers</h2>
        <a href="add_officer.php" class="btn btn-dark">Add Officer</a>
    </div>

    <?php if ($flash_success): ?>
        <div class="alert alert-success"><?= $flash_success ?></div>
    <?php endif; ?>

    <!-- Search bar -->
    <form method="get" class="mb-3">
        <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Search by Name, Username, Rank, CNIC, Department..." value="<?= htmlspecialchars($search) ?>">
            <button class="btn btn-primary" type="submit">Search</button>
            <?php if ($search): ?>
                <a href="list_officers.php" class="btn btn-secondary">Clear</a>
            <?php endif; ?>
        </div>
    </form>

    <table class="table table-striped table-hover align-middle">
        <thead class="table-dark">
            <tr>
                <th>#</th>
                <th>Photo</th>
                <th>Full Name</th>
                <th>Username</th>
                <th>Rank</th>
                <th>CNIC</th>
                <th>Department</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($officers): ?>
                <?php foreach ($officers as $officer): ?>
                    <tr>
                        <td><?= $officer['officer_id'] ?></td>
                        <td>
                            <?php
                            $photo_path = "../uploads/officers/" . ($officer['photo'] ?: '');
                            if (!empty($officer['photo']) && file_exists($photo_path)) {
                                echo '<img src="' . $photo_path . '" alt="Officer Photo" class="img-thumbnail" style="max-width:70px;">';
                            } else {
                                // Default placeholder
                                echo '<img src="../assets/default_officer.png" alt="No Photo" class="img-thumbnail" style="max-width:70px;">';
                            }
                            ?>
                        </td>
                        <td><?= htmlspecialchars($officer['user_name']) ?></td>
                        <td><?= htmlspecialchars($officer['username']) ?></td>
                        <td><?= htmlspecialchars($officer['rank']) ?></td>
                        <td><?= htmlspecialchars($officer['cnic']) ?></td>
                        <td><?= htmlspecialchars($officer['dept_name'] ?? '—') ?></td>
                        <td>
                            <a href="edit_officer.php?id=<?= $officer['officer_id'] ?>" class="btn btn-sm btn-primary">Edit</a>
                            <a href="delete_officer.php?officer_id=<?= $officer['officer_id'] ?>" class="btn btn-sm btn-danger" 
                               onclick="return confirm('Are you sure you want to delete this officer?')">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="8" class="text-center">No officers found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include "../includes/footer.php"; ?>
