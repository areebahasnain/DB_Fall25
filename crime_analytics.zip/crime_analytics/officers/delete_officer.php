<?php
require_once "../config/database.php";
require_once "../includes/functions.php";
require_once "../includes/auth.php";

// Only Admin can delete
if ($_SESSION['role'] !== 'Admin') {
    die("Access denied");
}

if (!isset($_GET['officer_id'])) {
    redirect('list_officers.php');
}

$officer_id = (int)$_GET['officer_id'];

// Fetch officer to ensure it exists
$stmt = $pdo->prepare("SELECT * FROM officers WHERE officer_id = ?");
$stmt->execute([$officer_id]);
$officer = $stmt->fetch();

if (!$officer) {
    redirect('list_officers.php');
}

// Count cases assigned to this officer
$stmt = $pdo->prepare("SELECT COUNT(*) as case_count FROM cases WHERE assigned_officer_id = ?");
$stmt->execute([$officer_id]);
$case = $stmt->fetch();
$case_count = $case['case_count'];

// If confirmation submitted
if (isset($_POST['confirm'])) {

    // 1️⃣ Delete the officer's photo file if it exists
    if (!empty($officer['photo']) && file_exists("../uploads/officers/" . $officer['photo'])) {
        unlink("../uploads/officers/" . $officer['photo']);
    }

    // 2️⃣ Delete officer record
    $stmt = $pdo->prepare("DELETE FROM officers WHERE officer_id = ?");
    $stmt->execute([$officer_id]);

    // 3️⃣ Flash message
    $_SESSION['success'] = "Officer '{$officer['rank']} (ID: {$officer['officer_id']})' deleted successfully.";

    redirect('list_officers.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete Officer</title>
    <link rel="stylesheet" href="/crime_analytics/assets/css/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container py-5">

    <div class="card p-4 shadow">
        <h3>Delete Officer</h3>

        <?php if ($case_count > 0): ?>
            <div class="alert alert-warning">
                This officer is currently assigned to <strong><?= $case_count ?></strong> case(s). 
                Deleting them will unassign these cases.
            </div>
        <?php else: ?>
            <div class="alert alert-info">
                Are you sure you want to delete this officer?
            </div>
        <?php endif; ?>

        <form method="post">
            <button type="submit" name="confirm" class="btn btn-danger">Yes, Delete Officer</button>
            <a href="list_officers.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>

</div>
</body>
</html>
